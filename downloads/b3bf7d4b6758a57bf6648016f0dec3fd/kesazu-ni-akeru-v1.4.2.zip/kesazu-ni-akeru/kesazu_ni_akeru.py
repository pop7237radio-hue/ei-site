#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
kesazu-ni-akeru / 消さずに空ける  v1.4.2

Codex の会話ログ (.jsonl) から、既知の4形式に入っている埋め込み画像データだけを
取り除く。会話テキストは残す。画像以外のバイト列が一致したことを証拠として残す。

- 対象: Codex / macOS / 手動実行のみ
- 依存: Python 3.9 標準ライブラリのみ
- 設計の芯: 「正規表現でファイル全体を置換」ではなく、
  JSON 構造で既知の場所を特定し、その値のバイト列だけを差し替える。
  既知でない場所に data:image があれば、そのファイルは触らずに HOLD する。

要求仕様: 01_安全版v1_要求仕様_実装前検品用.md (Sol Ultra)
試験:     02_試験マトリクス.md  全103件（test_kesazu.py）
"""

import argparse
import errno
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time

TOOL_NAME = "kesazu-ni-akeru"
TOOL_VERSION = "1.4.2"
CONTRACT_VERSION = "known-forms-2026-08-05"

# ---------------------------------------------------------------------------
# 既知形式の契約 (要求仕様 §3)
#   2026-08-05 に ~/.codex/sessions の直近40ファイルを走査して列挙したもの。
#   ここに無い場所に埋め込み画像があれば「未知」として HOLD する。推測しない。
# ---------------------------------------------------------------------------

# 埋め込み画像が入る場所。値は data URI 文字列。
KNOWN_IMAGE_PATHS = frozenset([
    "/payload/content/[]/image_url",
    "/payload/output/[]/image_url",
    "/payload/replacement_history/[]/content/[]/image_url",
    "/payload/result/Ok/_meta/codex/toolSurface/screenshot/url",
])

# content/output/replacement_history の配下では、この type のときだけ画像とみなす。
KNOWN_IMAGE_ITEM_TYPE = "input_image"

# 「どの種類の記録の、どの場所か」までを契約にする。
#   場所（JSON Pointer）だけを見ていると、将来 Codex が新しい種類の記録で
#   同じ場所を別の意味に使い始めたときに、黙って書き換えてしまう。
#   そこで (記録の種類, payload の種類, 場所) の3つ組が一致したときだけ画像として扱う。
#
# 実測: 2026-08-05、~/.codex/sessions の全 745 ファイル / 1,673,864 行を走査。
#       埋め込み画像が実在したのは以下の5通りだけだった（合計 72,225 箇所）。
#         compacted                          64,145
#         response_item/message               2,788
#         response_item/custom_tool_call_output 2,433
#         event_msg/mcp_tool_call_end         1,629
#         response_item/function_call_output   1,230
#       ※ compacted の payload に "type" キーは無い（実測）。だから None。
KNOWN_IMAGE_CONTRACT = frozenset([
    ("compacted", None, "/payload/replacement_history/[]/content/[]/image_url"),
    ("response_item", "message", "/payload/content/[]/image_url"),
    ("response_item", "custom_tool_call_output", "/payload/output/[]/image_url"),
    ("response_item", "function_call_output", "/payload/output/[]/image_url"),
    ("event_msg", "mcp_tool_call_end",
     "/payload/result/Ok/_meta/codex/toolSurface/screenshot/url"),
])

# 「data:image という文字列を含みうるが、画像ではない」既知の本文フィールド。
# 実測で59件見つかった罠。ここは絶対に触らない。HOLD の理由にもしない。
KNOWN_TEXT_PATHS = frozenset([
    "/payload/message",
    "/payload/last_agent_message",
    "/payload/content/[]/text",
    "/payload/output/[]/text",
    "/payload/replacement_history/[]/content/[]/text",
    "/payload/changes/*/content",
    "/payload/changes/*/update/unified_diff",
    "/payload/changes/*/add/content",
])

DATA_URI_RE = re.compile(r"data:image/[A-Za-z0-9.+\-]+;base64,")
DATA_URI_BYTES_RE = re.compile(rb"data:image/[A-Za-z0-9.+\-]+;base64,")

# 既知の画像フィールドにあっても、これより短い中身は「本物の埋め込み画像ではない」
# として触らない。他のツールが先に処理した残骸や、置き換え札が入っていることがあるため。
# 実測（2026-08-05・n=7,455）では、本物の最小が 80,038 文字。ここは十分下に取ってある。
MIN_IMAGE_PAYLOAD_CHARS = 1024

MARKER_PREFIX = "kesazu-ni-akeru:removed-embedded-image;v1;"
MARKER_RE = re.compile(re.escape(MARKER_PREFIX) + r"sha256=[0-9a-f]{64};bytes=\d+")

# canonical 比較用の置き換え札。画像の中身に絶対に現れないバイト列にする。
CANON_TOKEN = b"\x00<KESAZU-IMAGE-SLOT>\x00"

LOCK_NAME = ".kesazu-ni-akeru.lock"
MANIFEST_NAME = "manifest.json"
RECENT_SEC = 24 * 60 * 60


class Halt(Exception):
    """安全に停止する。書き換えは起きていない。"""


# ---------------------------------------------------------------------------
# 小道具
# ---------------------------------------------------------------------------

def now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime())


def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def eprint(*a):
    print(*a, file=sys.stderr)


def human(n):
    f = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if f < 1024.0 or unit == "TB":
            return ("%.1f%s" % (f, unit)) if unit != "B" else ("%dB" % n)
        f /= 1024.0


# ---------------------------------------------------------------------------
# JSON 構造の走査
# ---------------------------------------------------------------------------

def _walk(obj, path, parent, key, out):
    """文字列を (正規化パス, 値, 親dict) で列挙する。"""
    if isinstance(obj, dict):
        for k, v in obj.items():
            if path == "/payload/changes":
                # changes の直下キーは絶対パス。ワイルドカードに畳む。
                _walk(v, path + "/*", obj, k, out)
            else:
                _walk(v, path + "/" + k, obj, k, out)
    elif isinstance(obj, list):
        for v in obj:
            _walk(v, path + "/[]", parent, key, out)
    elif isinstance(obj, str):
        out.append((path, obj, parent))


def classify_line(raw_line):
    """
    1行を分類する。

    returns dict:
      ok            : JSON として読めたか
      images        : 既知の画像フィールドに入っていた data URI 文字列のリスト（これから外すもの）
      slots         : 既知の画像フィールドに入っていた値すべて（data URI と処理済みの札の両方）。
                      画像以外の比較（canonical）は、この位置を同じ札に潰してから行う。
      unknown       : 既知でない場所に現れた data:image の件数
      unknown_paths : その場所（先頭5件・報告用）
    """
    res = {"ok": False, "images": [], "slots": [], "tiny": 0,
           "unknown": 0, "unknown_paths": []}
    try:
        obj = json.loads(raw_line)
    except Exception:
        return res
    res["ok"] = True

    if not isinstance(obj, (dict, list)):
        return res

    strings = []
    _walk(obj, "", None, None, strings)

    # 「どの種類の記録か」。契約の照合に使う。
    etype = obj.get("type") if isinstance(obj, dict) else None
    _pay = obj.get("payload") if isinstance(obj, dict) else None
    ptype_payload = _pay.get("type") if isinstance(_pay, dict) else None

    for path, val, parent in strings:
        has_uri = ("data:image/" in val and ";base64," in val)
        marker_like = val.startswith(MARKER_PREFIX)
        # 札は「前置きが合っている」だけでは信用しない。形まで完全に一致したものだけを札と認める。
        is_marker = marker_like and MARKER_RE.fullmatch(val) is not None
        if not has_uri and not marker_like:
            continue

        if path in KNOWN_IMAGE_PATHS:
            # 場所が合っていても、記録の種類が既知の組み合わせでなければ触らない。(P0-5)
            if (etype, ptype_payload, path) not in KNOWN_IMAGE_CONTRACT:
                res["unknown"] += 1
                if len(res["unknown_paths"]) < 5:
                    res["unknown_paths"].append(
                        "%s (未知の記録種別 type=%r/%r)" % (path, etype, ptype_payload))
                continue
            # content/output/replacement_history 配下は type も確かめる
            if path.endswith("/image_url"):
                ptype = parent.get("type") if isinstance(parent, dict) else None
                if ptype != KNOWN_IMAGE_ITEM_TYPE:
                    res["unknown"] += 1
                    if len(res["unknown_paths"]) < 5:
                        res["unknown_paths"].append("%s (type=%r)" % (path, ptype))
                    continue
            if is_marker:
                res["slots"].append(val)
                continue  # 処理済み。再処理しない (T17)
            if marker_like:
                # 札の形が崩れている。誰かが触ったあとかもしれないので、推測せず HOLD にする。
                res["unknown"] += 1
                if len(res["unknown_paths"]) < 5:
                    res["unknown_paths"].append(path + " (broken-marker)")
                continue
            if DATA_URI_RE.match(val):
                payload = val.split(";base64,", 1)[1]
                if len(payload) < MIN_IMAGE_PAYLOAD_CHARS:
                    # 別のツールが先に中身を抜いた残骸など。触っても小さくならないので触らない。
                    res["tiny"] += 1
                    continue
                res["images"].append(val)
                res["slots"].append(val)
            else:
                # data:image を含むが先頭ではない = 既知フィールドの想定外の形
                res["unknown"] += 1
                if len(res["unknown_paths"]) < 5:
                    res["unknown_paths"].append(path + " (not-a-data-uri-head)")
            continue

        if path in KNOWN_TEXT_PATHS:
            continue  # 本文中の文字列。触らない (T05)

        if is_marker or (marker_like and not has_uri):
            continue

        res["unknown"] += 1
        if len(res["unknown_paths"]) < 5:
            res["unknown_paths"].append(path)

    return res


def encode_json_string_body(s):
    """JSON 文字列としてのエンコード結果から、囲みの引用符を外したもの。"""
    return json.dumps(s, ensure_ascii=False)[1:-1].encode("utf-8")


def make_marker(value):
    payload = value.split(";base64,", 1)[1]
    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    return "%ssha256=%s;bytes=%d" % (MARKER_PREFIX, digest, len(payload))


def canonicalize(raw_bytes, values):
    """既知画像の値だけを固定札に潰したバイト列。画像以外の比較に使う。"""
    out = raw_bytes
    for v in sorted(set(values), key=len, reverse=True):
        out = out.replace(encode_json_string_body(v), CANON_TOKEN)
    return out


# ---------------------------------------------------------------------------
# ファイル1本の解析
# ---------------------------------------------------------------------------

def analyze_file(path):
    """読むだけ。1バイトも書かない。"""
    # 権限と更新日時も控えておく。
    # 復元のときに「控えの姿」ではなく「原本の姿」へ戻すために要る。
    # （控えの置き場が ExFAT の外付けだと、権限も時刻の刻みも保てないため）
    _st = os.stat(path)
    info = {
        "relative_path": None,
        "before_size": _st.st_size,
        "before_mode": stat.S_IMODE(_st.st_mode),
        "before_mtime_ns": _st.st_mtime_ns,
        "after_size": None,
        "embedded_images": 0,
        "before_sha256": None,
        "canonical_non_image_sha256_before": None,
        "canonical_non_image_sha256_after": None,
        "line_count_before": 0,
        "line_count_after": None,
        "json_errors_before": 0,
        "json_errors_after": None,
        "status": "skipped",
        "reason": "",
        "reclaimable_bytes": 0,
        "tiny_left_alone": 0,
        "unknown_hits": 0,
        "unknown_paths": [],
    }

    canon = hashlib.sha256()
    plan = []  # [(line_index, [values...])]
    reclaim = 0

    with open(path, "rb") as fh:
        for idx, raw in enumerate(fh):
            info["line_count_before"] += 1
            cls = classify_line(raw)
            if not cls["ok"]:
                info["json_errors_before"] += 1
            info["unknown_hits"] += cls["unknown"]
            info["tiny_left_alone"] += cls["tiny"]
            for p in cls["unknown_paths"]:
                if len(info["unknown_paths"]) < 5:
                    info["unknown_paths"].append("L%d %s" % (idx + 1, p))
            if cls["images"]:
                plan.append((idx, cls["images"]))
                info["embedded_images"] += len(cls["images"])
                for v in cls["images"]:
                    reclaim += len(encode_json_string_body(v)) - len(
                        encode_json_string_body(make_marker(v)))
            canon.update(canonicalize(raw, cls["slots"]))

    info["before_sha256"] = sha256_file(path)
    info["canonical_non_image_sha256_before"] = canon.hexdigest()
    info["reclaimable_bytes"] = reclaim

    if info["json_errors_before"] > 0:
        info["status"] = "held"
        info["reason"] = "JSONとして読めない行が%d件ある。ファイル全体を触らない (T06)" % info["json_errors_before"]
        return info, plan
    if info["unknown_hits"] > 0:
        info["status"] = "held"
        info["reason"] = "既知でない場所に画像データらしきものが%d件ある。推測処理しない (T07): %s" % (
            info["unknown_hits"], "; ".join(info["unknown_paths"]))
        return info, plan
    if info["embedded_images"] == 0:
        info["status"] = "skipped"
        info["reason"] = ("埋め込み画像なし"
                          + ("（別ツール処理済みらしき残骸 %d 件は触りません）" % info["tiny_left_alone"]
                             if info["tiny_left_alone"] else ""))
        return info, plan

    if info["reclaimable_bytes"] <= 0:
        # 置き換えると逆に大きくなる。やる意味がないので触らない。
        info["status"] = "skipped"
        info["reason"] = "取り除いても小さくならないため触りません"
        return info, plan

    mtime = os.path.getmtime(path)
    if (time.time() - mtime) < RECENT_SEC:
        info["status"] = "held"
        info["reason"] = "24時間以内に更新されている。使用中の可能性があるため触らない (T10)"
        return info, plan

    info["status"] = "candidate"
    return info, plan


# ---------------------------------------------------------------------------
# 収集
# ---------------------------------------------------------------------------

def resolve_root(root):
    p = os.path.abspath(os.path.expanduser(root))
    if os.path.islink(p):
        raise Halt("--root が symlink です。拒否します: %s" % root)
    if not os.path.isdir(p):
        raise Halt("--root がフォルダではありません: %s" % root)
    return os.path.realpath(p)


def iter_targets(root):
    """root 配下の通常ファイルの .jsonl だけ。symlink とツリー外は拒否。"""
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        dirnames[:] = [d for d in dirnames
                       if not os.path.islink(os.path.join(dirpath, d))
                       and d not in (".git", "__pycache__")]
        for name in sorted(filenames):
            if not name.endswith(".jsonl"):
                continue
            full = os.path.join(dirpath, name)
            if os.path.islink(full):
                continue
            st = os.lstat(full)
            if not stat.S_ISREG(st.st_mode):
                continue
            real = os.path.realpath(full)
            if not (real == root or real.startswith(root + os.sep)):
                continue  # path traversal
            yield full


def _stable_realpath(p):
    """
    まだ無いパスでも realpath 相当に正規化する。
    （/var と /private/var のように、途中が symlink の環境で判定を外さないため）
    """
    p = os.path.abspath(os.path.expanduser(p))
    head, tail = p, []
    while not os.path.exists(head):
        head, t = os.path.split(head)
        if not t:
            break
        tail.append(t)
    return os.path.join(os.path.realpath(head), *reversed(tail))


def safe_join(base, rel, label):
    """
    記録（manifest）に書かれた相対パスを、base の中に閉じ込めて結合する。

    記録は書き換えられうる前提で扱う。絶対パス・`..`・途中の symlink を全部拒否し、
    base の外へ出る結合は必ず止める。ここを通らないパスは、読むことも消すこともしない。
    """
    if not isinstance(rel, str) or not rel:
        raise Halt("%s の記録が壊れています（パスが文字列ではありません）" % label)
    if os.path.isabs(rel) or (os.path.altsep and os.path.isabs(rel.replace(os.path.altsep, os.sep))):
        raise Halt("%s の記録に絶対パスが入っています。拒否します: %r" % (label, rel))
    parts = [q for q in re.split(r"[/\\]", rel) if q not in ("", ".")]
    if any(q == ".." for q in parts):
        raise Halt("%s の記録に上位フォルダ参照(..)が入っています。拒否します: %r" % (label, rel))
    if not parts:
        raise Halt("%s の記録が空です" % label)

    rbase = os.path.realpath(base)
    cur = rbase
    for q in parts:
        cur = os.path.join(cur, q)
        # 途中に symlink があれば、その先がどこであれ拒否する
        if os.path.islink(cur):
            raise Halt("%s の途中に symlink があります。拒否します: %s" % (label, cur))
    full = os.path.join(rbase, *parts)

    # 実体があれば realpath でも閉じ込めを確認する（作成前は親までで確認）
    check = full if os.path.exists(full) else os.path.dirname(full)
    if os.path.exists(check):
        rcheck = os.path.realpath(check)
        if not (rcheck == rbase or rcheck.startswith(rbase + os.sep)):
            raise Halt("%s が対象フォルダの外を指しています。拒否します: %r" % (label, rel))
    return full


def assert_separate(root, other, label):
    o = os.path.abspath(os.path.expanduser(other))
    ro = _stable_realpath(other)
    if ro == root or ro.startswith(root + os.sep):
        raise Halt("%s を --root の中に置けません (T20): %s" % (label, other))
    if root.startswith(ro + os.sep):
        raise Halt("%s が --root を含んでいます: %s" % (label, other))
    return o


def _pid_alive(pid):
    try:
        os.kill(pid, 0)
    except OSError as e:
        return e.errno != errno.ESRCH
    return True


def root_lock_path(root):
    """
    対象フォルダごとの鍵。report-dir を変えても二重実行にならないようにする。(P1)
    対象フォルダの中には書かない（あそこは利用者のデータなので触らない）。
    """
    d = os.path.join(os.path.expanduser("~"), ".cache", TOOL_NAME, "locks")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, hashlib.sha256(root.encode("utf-8")).hexdigest()[:32] + ".lock")


class Lock(object):
    """
    多重起動を止める。置き去りの鍵（前回が落ちた等）は、そのPIDが生きていない時だけ引き取る。
    """

    def __init__(self, directory=None, path=None, label=None):
        self.path = path if path else os.path.join(directory, LOCK_NAME)
        self.label = label or self.path
        self.fd = None

    def _try(self):
        self.fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)

    def __enter__(self):
        try:
            self._try()
        except OSError as e:
            if e.errno != errno.EEXIST:
                raise
            # 置き去りかどうかを確かめる
            holder = None
            try:
                with open(self.path, "r", encoding="utf-8", errors="replace") as fh:
                    holder = int(fh.read().split()[0])
            except Exception:
                holder = None
            if holder is not None and _pid_alive(holder):
                raise Halt("すでに実行中です (%s / pid %d)。二重に動かしません (T13)"
                           % (self.label, holder))
            try:
                os.unlink(self.path)
            except OSError:
                pass
            try:
                self._try()
            except OSError:
                raise Halt("すでに実行中です (%s)。二重に動かしません (T13)" % self.label)
        os.write(self.fd, ("%d %s\n" % (os.getpid(), now_iso())).encode())
        return self

    def __exit__(self, *a):
        if self.fd is not None:
            os.close(self.fd)
            self.fd = None
        try:
            os.unlink(self.path)
        except OSError:
            pass


def codex_running():
    try:
        out = subprocess.run(["ps", "-Ao", "comm="], capture_output=True, text=True, timeout=10)
    except Exception:
        return None  # 判定できない
    for line in out.stdout.splitlines():
        base = os.path.basename(line.strip())
        if base == "codex" or base.startswith("codex-"):
            return True
    return False


# ---------------------------------------------------------------------------
# diagnose
# ---------------------------------------------------------------------------

def cmd_diagnose(args):
    root = resolve_root(args.root)
    report_dir = assert_separate(root, args.report_dir, "--report-dir")
    os.makedirs(report_dir, exist_ok=True)

    # すでに apply 済みの記録を上書きしない。
    # 上書きすると「どこに戻せばよいか」が消えて、復元できなくなる。
    mpath_pre = os.path.join(report_dir, MANIFEST_NAME)
    if os.path.exists(mpath_pre):
        try:
            prev = read_json(mpath_pre)
        except Exception:
            prev = None
        if isinstance(prev, dict) and isinstance(prev.get("files"), list):
            live = [e for e in prev["files"]
                    if isinstance(e, dict)
                    and e.get("status") in ("changed", "replacing")
                    and e.get("backup_path")
                    and not e.get("backup_committed")]
            if live:
                raise Halt(
                    "この記録には、まだ戻せる状態の処理結果が %d 件入っています。\n"
                    "  上書きすると復元できなくなるため、診断を中止しました。\n"
                    "  戻すなら restore、確定するなら verify → commit、\n"
                    "  やり直すなら --report-dir に別のフォルダを指定してください: %s"
                    % (len(live), mpath_pre))

    synthetic = getattr(args, "synthetic", False)
    with Lock(report_dir):
        # self-test は temp に作った作り物だけが対象なので、Codex の起動可否は関係ない
        running = False if synthetic else codex_running()
        files = list(iter_targets(root))
        entries = []
        total_reclaim = 0
        for full in files:
            info, _ = analyze_file(full)
            info["relative_path"] = os.path.relpath(full, root)
            if running is True and info["status"] == "candidate":
                info["status"] = "held"
                info["reason"] = "Codex が起動中です。終了してから実行してください"
            if info["status"] == "candidate":
                total_reclaim += info["reclaimable_bytes"]
            entries.append(info)

        usage = shutil.disk_usage(root)
        manifest = {
            "tool_version": TOOL_VERSION,
            "contract_version": CONTRACT_VERSION,
            "started_at": now_iso(),
            "mode": "diagnose",
            "root": root,
            "codex_running": running,
            "disk_free_bytes": usage.free,
            "estimated_reclaim_bytes": total_reclaim,
            "files": entries,
        }
        mpath = os.path.join(report_dir, MANIFEST_NAME)
        write_json(mpath, manifest)

    cand = [e for e in entries if e["status"] == "candidate"]
    held = [e for e in entries if e["status"] == "held"]
    print("== 診断だけしました。1バイトも書き換えていません ==")
    print("  対象フォルダ      : %s" % root)
    print("  .jsonl            : %d 本" % len(entries))
    print("  処理できるもの    : %d 本 / 画像 %d 枚" % (len(cand), sum(e["embedded_images"] for e in cand)))
    print("  触らないもの      : %d 本" % len(held))
    print("  見込みの回収量    : %s  ※環境によって異なります" % human(total_reclaim))
    print("  ディスクの空き    : %s" % human(usage.free))
    if running is True:
        print("  ⚠ Codex が起動中です。終了してから apply してください")
    for e in held[:10]:
        print("    - HOLD %s : %s" % (e["relative_path"], e["reason"][:100]))
    print("\n  記録: %s" % os.path.join(report_dir, MANIFEST_NAME))
    if running is True and not cand:
        print("  次にやること: Codex を終了してから、もう一度 diagnose からやり直してください。")
        print("    （起動中は安全のため全部 HOLD にしています。いま apply しても対象は0本です）")
    elif not cand:
        print("  次にやること: 取り除けるものがありませんでした。apply は不要です。")
    else:
        print("  次にやること: 中身を確かめてから apply（バックアップ先の指定が要ります）")
    return 0


def write_json(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, ensure_ascii=False, indent=2)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)


def read_json(path):
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


# ---------------------------------------------------------------------------
# apply
# ---------------------------------------------------------------------------

def convert_file(src, entry):
    """
    1本を変換して一時ファイルを作る。戻り値は (tmp_path, after_info)。
    画像以外のバイト列が変わっていたら例外を投げる（原本は無傷）。
    """
    d = os.path.dirname(src)
    fd, tmp = tempfile.mkstemp(dir=d, prefix=".kesazu-", suffix=".tmp")
    canon_after = hashlib.sha256()
    lines_after = 0
    json_err_after = 0
    replaced = 0
    try:
        with os.fdopen(fd, "wb") as out, open(src, "rb") as fh:
            for raw in fh:
                cls = classify_line(raw)
                new = raw
                if cls["ok"] and cls["images"] and cls["unknown"] == 0:
                    markers = []
                    # 同じ画像が1行に複数回出ることがある（replacement_history）。
                    # 値ごとに1回だけ処理する。長いものから replace して部分一致を避ける。
                    uniq = sorted(set(cls["images"]), key=len, reverse=True)
                    for v in uniq:
                        enc = encode_json_string_body(v)
                        n_struct = cls["images"].count(v)
                        n_raw = new.count(enc)
                        if n_raw != n_struct:
                            raise Halt(
                                "行の中で画像データの出現数が構造と一致しません "
                                "(構造%d / バイト%d)。この行は書き換えません" % (n_struct, n_raw))
                        mk = make_marker(v)
                        new = new.replace(enc, encode_json_string_body(mk))
                        markers.append(mk)
                        replaced += n_struct
                    # 置換後も JSON として読めるか
                    try:
                        json.loads(new)
                    except Exception:
                        raise Halt("置換したら JSON が壊れました。中止します")
                    canon_after.update(canonicalize(new, classify_line(new)["slots"]))
                else:
                    canon_after.update(canonicalize(raw, cls["slots"]))
                if not cls["ok"]:
                    json_err_after += 1
                out.write(new)
                lines_after += 1
            out.flush()
            os.fsync(out.fileno())
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise

    after = {
        "line_count_after": lines_after,
        "json_errors_after": json_err_after,
        "canonical_non_image_sha256_after": canon_after.hexdigest(),
        "after_size": os.path.getsize(tmp),
        "replaced": replaced,
    }
    return tmp, after


def cmd_apply(args):
    if args.confirm != "REMOVE_EMBEDDED_IMAGES":
        raise Halt("--confirm REMOVE_EMBEDDED_IMAGES が要ります。何も書き換えていません")

    root = resolve_root(args.root)
    report_dir = assert_separate(root, args.report_dir, "--report-dir")
    backup_dir = assert_separate(root, args.backup_dir, "--backup-dir")
    mpath = os.path.join(report_dir, MANIFEST_NAME)
    if not os.path.exists(mpath):
        raise Halt("先に diagnose を実行してください（記録が見つかりません: %s）" % mpath)
    diag = read_json(mpath)
    if diag.get("root") != root:
        raise Halt("記録の対象フォルダと --root が違います。中止します")

    if not getattr(args, "synthetic", False) and codex_running() is True:
        raise Halt("Codex が起動中です。終了してから実行してください")

    os.makedirs(backup_dir, exist_ok=True)

    # このrun専用のバックアップ先を新規に作る。すでにあれば失敗させる。
    # （前回のバックアップを上書きして壊さないため。P0-4）
    # 名前が万一ぶつかっても失敗しないよう、作成そのもので一意を取る。
    # （同じ秒に2回動かすと "run-日時-pid" は同名になりうる）
    try:
        run_backup = tempfile.mkdtemp(
            prefix="run-%s-" % time.strftime("%Y%m%d-%H%M%S"), dir=backup_dir)
    except OSError as ex:
        raise Halt("バックアップ先を新しく作れませんでした（%s）: %s" % (ex, backup_dir))
    os.chmod(run_backup, 0o700)
    # 以後の結合・相対化がぶれないよう実体パスに寄せる（/var と /private/var 対策）
    run_backup = os.path.realpath(run_backup)

    same_volume = os.stat(root).st_dev == os.stat(run_backup).st_dev
    cands = [e for e in diag["files"] if e["status"] == "candidate"]
    if not cands:
        # 何もしなかったことを、記録にもそう書いてから終わる。(P1)
        #   ここで書かずに帰ると、記録は diagnose のまま残る。
        #   利用者から見れば apply は終わっているので、そのまま verify を打つ。
        #   すると照合対象が0本なのに「すべて一致しました」と出てしまう。
        os.rmdir(run_backup)
        with Lock(report_dir):
            write_json(mpath, {
                "tool_version": TOOL_VERSION,
                "contract_version": CONTRACT_VERSION,
                "started_at": now_iso(),
                "mode": "apply",
                "root": root,
                "backup_dir": None,
                "candidates": 0,
                "files": [dict(e) for e in diag["files"]],
            })
        print("取り除けるものがありませんでした。1バイトも書き換えていません。")
        print("  記録: %s" % mpath)
        return 0

    need = sum(e["before_size"] for e in cands)           # バックアップぶん
    biggest = max([e["before_size"] for e in cands] + [0])
    free_b = shutil.disk_usage(run_backup).free
    if free_b < (need + biggest) * 1.05:
        raise Halt("空き容量が足りません。必要 %s / 空き %s。何も書き換えていません (T14)"
                   % (human(need + biggest), human(free_b)))
    # 一時ファイルは対象ディスク側に作る。バックアップ先が別ディスクでも、こちらの空きが要る。
    if not same_volume:
        free_r = shutil.disk_usage(root).free
        if free_r < biggest * 1.05:
            raise Halt("対象ディスクの空きが足りません（一時ファイル用）。必要 %s / 空き %s。"
                       "何も書き換えていません" % (human(biggest), human(free_r)))

    print("== これから書き換えます ==")
    print("  対象      : %d 本" % len(cands))
    print("  バックアップ先: %s" % run_backup)
    if same_volume:
        print("  ⚠ バックアップ先が対象と同じディスクです。")
        print("     commit するまで、実際の空きは増えません（複製を持つため）。")
    else:
        print("  別のディスクなので、復元できるまま対象ディスクの空きが増えます。")

    manifest = {
        "tool_version": TOOL_VERSION,
        "contract_version": CONTRACT_VERSION,
        "started_at": now_iso(),
        "mode": "apply",
        "root": root,
        "backup_dir": os.path.abspath(run_backup),
        "backup_same_volume": same_volume,
        "candidates": len(cands),
        "files": [],
    }
    handled = {}

    def flush(cur_entry=None):
        """途中で電源が落ちても、記録が実態より楽観的にならないようにする。(P0-3)"""
        files = []
        for src_e in diag["files"]:
            key = src_e["relative_path"]
            if key in handled:
                files.append(handled[key])
            elif cur_entry is not None and key == cur_entry["relative_path"]:
                files.append(cur_entry)
            else:
                files.append(dict(src_e))
        manifest["files"] = files
        write_json(mpath, manifest)

    with Lock(report_dir), Lock(path=root_lock_path(root), label="対象フォルダ"):
        flush()
        for e in cands:
            src = safe_join(root, e["relative_path"], "対象ファイル")
            entry = dict(e)
            try:
                st = os.lstat(src)
                if not stat.S_ISREG(st.st_mode) or os.path.islink(src):
                    raise Halt("通常ファイルではありません")
                if st.st_size != e["before_size"] or sha256_file(src) != e["before_sha256"]:
                    raise Halt("診断のあとで中身が変わっています。この1本は飛ばします (T12)")

                # 1) バックアップ（新規作成のみ。既存があれば絶対に上書きしない）
                bdst = safe_join(run_backup, e["relative_path"], "バックアップ先")
                os.makedirs(os.path.dirname(bdst), exist_ok=True)
                try:
                    bfd = os.open(bdst, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
                except OSError as ex:
                    raise Halt("バックアップ先にすでにファイルがあります。上書きしません: %s (%s)"
                               % (bdst, ex))
                try:
                    with os.fdopen(bfd, "wb") as bo, open(src, "rb") as bi:
                        shutil.copyfileobj(bi, bo, 1024 * 1024)
                        bo.flush()
                        os.fsync(bo.fileno())
                except BaseException:
                    try:
                        os.unlink(bdst)
                    except OSError:
                        pass
                    raise
                shutil.copystat(src, bdst)
                if sha256_file(bdst) != e["before_sha256"]:
                    raise Halt("バックアップの照合に失敗しました。原本は触っていません")
                entry["backup_path"] = e["relative_path"]
                entry["backup_sha256"] = e["before_sha256"]

                # 2) 変換（一時ファイル）
                tmp, after = convert_file(src, e)
                try:
                    # 3) 検算。ここを通らないものは置換しない
                    if after["canonical_non_image_sha256_after"] != e["canonical_non_image_sha256_before"]:
                        raise Halt("画像以外のバイト列が変わりました。置換しません (P0)")
                    if after["line_count_after"] != e["line_count_before"]:
                        raise Halt("行数が変わりました。置換しません (P0)")
                    if after["json_errors_after"] != e["json_errors_before"]:
                        raise Halt("JSON として読めない行が増えました。置換しません (P0)")

                    # 3b) 置換の直前にもう一度、原本が動いていないか確かめる。
                    #     読み取りから置換までの隙に追記されると、その追記ごと消えるため。(P0-2)
                    st2 = os.lstat(src)
                    if (not stat.S_ISREG(st2.st_mode)
                            or st2.st_size != e["before_size"]
                            or st2.st_ino != st.st_ino
                            or st2.st_mtime_ns != st.st_mtime_ns
                            or sha256_file(src) != e["before_sha256"]):
                        raise Halt("処理中に原本が変わりました。この1本は書き換えません (T12)")

                    # 4) 原子的置換 + mode/mtime 保持
                    os.chmod(tmp, stat.S_IMODE(st.st_mode))
                    entry["status"] = "replacing"
                    entry["reason"] = "置換中に中断された可能性があります。verify で確かめてください"
                    entry.update(after)
                    flush(entry)          # ← 置換の「前」に記録する。後で落ちても嘘にならない
                    os.replace(tmp, src)
                    tmp = None
                finally:
                    if tmp is not None:
                        try:
                            os.unlink(tmp)
                        except OSError:
                            pass

                try:
                    # 秒を小数で渡すと ns の下の桁が丸まる。ns のまま渡して同じ時刻に戻す。
                    os.utime(src, ns=(st.st_atime_ns, st.st_mtime_ns))
                except OSError as ex:
                    entry["utime_restored"] = False
                    entry["utime_error"] = "%r" % (ex,)
                else:
                    entry["utime_restored"] = True

                entry["status"] = "changed"
                entry["reason"] = ""
                print("  ✓ %s  %s → %s" % (e["relative_path"],
                                            human(e["before_size"]), human(after["after_size"])))
            except Halt as ex:
                if entry.get("status") != "replacing":
                    entry["status"] = "failed"
                    entry["reason"] = str(ex)
                print("  ✗ %s  %s" % (e["relative_path"], ex))
            except BaseException as ex:  # 想定外も中断も、記録を残してから投げ直す
                if entry.get("status") != "replacing":
                    entry["status"] = "failed"
                    entry["reason"] = "想定外: %r" % (ex,)
                print("  ✗ %s  想定外: %r" % (e["relative_path"], ex))
                handled[e["relative_path"]] = entry
                flush()
                if not isinstance(ex, Exception):
                    raise
            handled[e["relative_path"]] = entry
            flush()

    out_entries = manifest["files"]
    changed = [e for e in out_entries if e["status"] == "changed"]
    failed = [e for e in out_entries if e["status"] in ("failed", "replacing")]
    saved = sum(e["before_size"] - e["after_size"] for e in changed)
    print("\n  書き換えた本数: %d" % len(changed))
    print("  取り除いた量  : %s  ※回収量は環境によって異なります" % human(saved))
    if failed:
        print("  できなかった本数: %d（原本はそのまま残っています）" % len(failed))
    if same_volume:
        print("  いまの時点では、同じディスクに複製があるので実質の空きは増えていません。")
        print("  verify で確かめてから commit すると、複製が消えて空きになります（戻せなくなります）。")
    print("  記録: %s" % mpath)
    return 0 if not failed else 2


# ---------------------------------------------------------------------------
# verify / restore / commit
# ---------------------------------------------------------------------------

def load_manifest(path, expect_root=None):
    """
    記録を読み込む。記録は書き換えられうる前提で、中身を全部検算してから使う。(P0-1)
    """
    m = read_json(path)
    if not isinstance(m, dict) or not isinstance(m.get("files"), list):
        raise Halt("記録の形が壊れています: %s" % path)
    root = m.get("root")
    if not isinstance(root, str) or not root:
        raise Halt("記録に対象フォルダが入っていません: %s" % path)
    root = resolve_root(root)          # symlink・非フォルダをここで弾く
    if expect_root is not None and resolve_root(expect_root) != root:
        raise Halt("記録の対象フォルダと --root が違います。中止します")
    m["root"] = root

    bdir = m.get("backup_dir")
    if bdir:
        if not isinstance(bdir, str):
            raise Halt("記録のバックアップ先が壊れています")
        rb = _stable_realpath(bdir)
        if rb == root or rb.startswith(root + os.sep) or root.startswith(rb + os.sep):
            raise Halt("記録のバックアップ先が対象フォルダと重なっています。中止します: %s" % bdir)
        m["backup_dir"] = rb
    return m


def cmd_verify(args):
    m = load_manifest(args.manifest, getattr(args, "expect_root", None))
    root = m["root"]
    ok = True
    rechecked = 0
    noted = 0          # 処理できなかったもの。原本は無傷なので照合の対象ではない
    interrupted = 0    # commit の途中で止まった控え。事故ではない (v2-B)
    for e in m["files"]:
        if e["status"] == "replacing":
            print("  ✗ %s : 置換の途中で中断された記録が残っています。restore で戻してください"
                  % e.get("relative_path"))
            ok = False
            continue
        if e["status"] == "failed":
            # 書き換えていないので照合するものは無い。
            # ただし黙って飛ばすと、全部失敗した記録が「異常なし」に見えてしまう。(P1)
            print("  ⚠ %s : 処理できませんでした（原本はそのままです）: %s"
                  % (e.get("relative_path"), (e.get("reason") or "")[:80]))
            noted += 1
            continue
        if e["status"] != "changed":
            continue
        src = safe_join(root, e["relative_path"], "対象ファイル")
        rechecked += 1
        if not os.path.exists(src):
            print("  ✗ %s : ファイルがありません" % e["relative_path"]); ok = False; continue
        info, _ = analyze_file(src)
        if info["canonical_non_image_sha256_before"] != e["canonical_non_image_sha256_before"]:
            print("  ✗ %s : 画像以外のバイト列が処理前と一致しません" % e["relative_path"]); ok = False
        elif info["line_count_before"] != e["line_count_before"]:
            print("  ✗ %s : 行数が違います" % e["relative_path"]); ok = False
        elif info["json_errors_before"] != e["json_errors_before"]:
            print("  ✗ %s : JSON エラー数が違います" % e["relative_path"]); ok = False
        elif info["embedded_images"] != 0:
            print("  ✗ %s : まだ埋め込み画像が %d 枚残っています" % (e["relative_path"], info["embedded_images"])); ok = False
        else:
            print("  ✓ %s" % e["relative_path"])
        if e.get("backup_committed"):
            continue   # commit で意図的に消した控え。無いのが正しい状態
        if e.get("backup_path") and m.get("backup_dir"):
            try:
                bpath = safe_join(m["backup_dir"], e["backup_path"], "バックアップ先")
            except Halt as ex:
                print("    ✗ %s" % ex); ok = False; continue
            if not os.path.exists(bpath):
                if m.get("mode") == "committing":
                    # 消した直後・記録に載る前に落ちた1本だけがここに来る。
                    # 利用者が消しにいった控えなので、事故として赤で出さない。(v2-B)
                    print("    ⚠ 控えがありません（commit の途中で止まっています）: %s" % bpath)
                    interrupted += 1
                else:
                    print("    ✗ バックアップがありません: %s" % bpath); ok = False
            elif sha256_file(bpath) != e["backup_sha256"]:
                print("    ✗ バックアップが処理前と一致しません: %s" % bpath); ok = False

    if rechecked == 0:
        # 「0本を照合して全部一致」は、利用者には「照合が通った」と読める。
        # 何も確かめていないことと、確かめて一致したことを、同じ緑で出さない。(P1)
        print("\n検証対象がありません（0 本を再検証）。「すべて一致した」ではありません。")
        if m.get("mode") == "diagnose":
            print("  この記録はまだ diagnose のままです。先に apply を実行してください。")
        elif m.get("candidates") == 0:
            print("  apply は動きましたが、取り除けるものが1本もありませんでした。")
            print("  照合するものが無いだけで、異常ではありません。")
        elif noted:
            print("  処理できたものが1本もありません（%d 本すべて失敗）。" % noted)
            print("  上の ⚠ の理由を確かめてください。原本はどれも書き換えていません。")
        else:
            print("  この記録には、照合できる処理済みのファイルが入っていません。")
        print("  この記録は verify 済みにしません（commit はできません）。")
        return 2

    print("\n%s（%d 本を再検証）" % ("すべて一致しました" if ok else "一致しないものがあります", rechecked))
    if noted:
        print("  ※ このほかに、処理できなかったものが %d 本あります（原本はそのままです）" % noted)
    if m.get("mode") == "committing":
        # 「異常なし」で終わらせない。片づけが途中だと本人に伝える。(v2-B)
        left = sum(1 for e in m["files"]
                   if e["status"] == "changed" and e.get("backup_path")
                   and not e.get("backup_committed"))
        print("  ※ commit が途中で止まっています（控えの残り %d 本%s）。"
              % (left, "・記録に載る前に消えた分 %d 本" % interrupted if interrupted else ""))
        print("     もう一度 commit を実行すると、始めた片づけを最後まで終えられます。")
    if ok:
        m["verified_at"] = now_iso()
        write_json(args.manifest, m)
    return 0 if ok else 2


def require_backup_dir(m, what_you_can_do):
    """
    バックアップ先を取り出す。無いときは、何が起きているのかが分かる言葉で止める。

    `backup_dir: None` をそのまま出すと、利用者には意味が通らない。(P1)
    """
    bdir = m.get("backup_dir")
    if not bdir:
        raise Halt("この記録には apply の記録がありません（バックアップ先が記録されていません）。\n"
                   "  %s\n"
                   "  まだ apply していないか、apply の対象が0本だった可能性があります。"
                   % what_you_can_do)
    if not os.path.isdir(bdir):
        raise Halt("記録にあるバックアップ先のフォルダが見つかりません"
                   "（移動または削除された可能性があります）: %s" % bdir)
    return bdir


def cmd_restore(args):
    if args.confirm != "RESTORE_ORIGINALS":
        raise Halt("--confirm RESTORE_ORIGINALS が要ります。何も戻していません")
    m = load_manifest(args.manifest, getattr(args, "expect_root", None))
    root = m["root"]
    bdir = require_backup_dir(m, "戻せるのは、apply で実際に書き換えたものだけです。")

    if not getattr(args, "synthetic", False) and codex_running() is True:
        raise Halt("Codex が起動中です。終了してから戻してください")

    # 置換の途中で止まったものも戻す対象に含める
    targets = [e for e in m["files"]
               if e["status"] in ("changed", "replacing") and e.get("backup_path")]
    if not targets:
        print("戻すものがありません。")
        return 0

    # 自分の commit で消した控えと、事故で無くなった控えを、同じ顔で出さない。(v2-C)
    # 「バックアップがありません: <パス>」だけを見せると、
    # あとから不安になって restore を打った人には事故が起きたように読める。
    committed = [e for e in targets if e.get("backup_committed")]
    if committed:
        when = m.get("committed_at") or m.get("commit_started_at") or "（日時の記録なし）"
        remain = len(targets) - len(committed)
        raise Halt(
            "commit で控えを消したファイルがあるため、戻せません（%d 本）。\n"
            "  これは事故ではありません。あなたが commit"
            "（--confirm DELETE_IMAGE_BACKUP_IRREVERSIBLY）を実行して消したものです: %s\n"
            "  取り除いた画像は復元できません。ログ本体は書き換え済みのまま無傷です。\n"
            "  %s" % (
                len(committed), when,
                ("控えが残っているものが %d 本あります＝commit が途中で止まっています。\n"
                 "  もう一度 commit を実行すると、始めた片づけを最後まで終えられます。" % remain)
                if remain else
                "控えはすべて消してあります。この記録で restore を使うことはもうありません。"))

    plan = []
    need = 0
    for e in targets:  # 先に全部の照合を通す。1つでも駄目なら1本も戻さない
        b = safe_join(bdir, e["backup_path"], "バックアップ先")
        src = safe_join(root, e["relative_path"], "対象ファイル")
        if not os.path.exists(b):
            # ここに来るのは commit で消したものではない＝想定外。事故と書いてよい。
            raise Halt("バックアップがありません（commit で消したものではありません＝想定外です）: %s" % b)
        if os.path.islink(b) or not stat.S_ISREG(os.lstat(b).st_mode):
            raise Halt("バックアップが通常ファイルではありません: %s" % b)
        if sha256_file(b) != e["backup_sha256"]:
            raise Halt("バックアップが記録と一致しません。戻しません (T19): %s" % b)
        need += os.path.getsize(b)
        plan.append((e, src, b))

    free = shutil.disk_usage(root).free
    if free < need * 1.05:
        raise Halt("戻すための空きが足りません。必要 %s / 空き %s。何も戻していません"
                   % (human(need), human(free)))

    ts = time.strftime("%Y%m%d-%H%M%S")
    restored = 0
    moved = []   # 見覚えのないものだけを退避する。自分が書いたものは残骸にしない

    def is_our_output(path, entry):
        """
        いま置いてあるファイルが『apply でこの道具が書いたもの』と言い切れるか。
        言い切れるのは、画像以外のバイト列が処理前と完全に一致していて、
        かつ埋め込み画像が1枚も残っていないとき（verify と同じ見方）。
        言い切れないもの（Codex が書き足した／利用者が編集した）は退避して残す。
        """
        try:
            info, _ = analyze_file(path)
        except Exception:
            return False
        return (info["canonical_non_image_sha256_before"]
                == entry["canonical_non_image_sha256_before"]
                and info["line_count_before"] == entry["line_count_before"]
                and info["json_errors_before"] == entry["json_errors_before"]
                and info["embedded_images"] == 0)
    with Lock(path=root_lock_path(root), label="対象フォルダ"):
        for e, src, b in plan:
            os.makedirs(os.path.dirname(src), exist_ok=True)
            # 一度わきに作ってから差し替える。途中で落ちても半端なファイルを残さない。
            fd, tmp = tempfile.mkstemp(dir=os.path.dirname(src), prefix=".kesazu-restore-")
            try:
                with os.fdopen(fd, "wb") as out, open(b, "rb") as bi:
                    shutil.copyfileobj(bi, out, 1024 * 1024)
                    out.flush()
                    os.fsync(out.fileno())
                if sha256_file(tmp) != e["before_sha256"]:
                    raise Halt("復元用の複製が記録と一致しません: %s" % e["relative_path"])
                shutil.copystat(b, tmp)
                # 控えの置き場（外付けが ExFAT など）は、権限も時刻の刻みも保てないことがある。
                # copystat はその「控えの姿」を写してしまうので、
                # 記録しておいた原本の値で上書きして、本当に元どおりにする。
                if e.get("before_mode") is not None:
                    try:
                        os.chmod(tmp, e["before_mode"])
                    except OSError:
                        pass
                if e.get("before_mtime_ns") is not None:
                    try:
                        # 変数名は ts を避ける。外側の ts は退避名に使う日時の文字列で、
                        # ここで潰すと退避のファイル名づくりが壊れる（2026-08-05 実際に壊した）
                        st_tmp = os.stat(tmp)
                        os.utime(tmp, ns=(st_tmp.st_atime_ns, e["before_mtime_ns"]))
                    except OSError:
                        pass
                if os.path.exists(src) and not is_our_output(src, e):
                    # 見覚えのないもの。上書きせず横へ置いて、あとで名前を出す
                    os.replace(src, src + ".kesazu-preexisting-" + ts)
                    moved.append(e["relative_path"] + ".kesazu-preexisting-" + ts)
                os.replace(tmp, src)
                tmp = None
            finally:
                if tmp is not None:
                    try:
                        os.unlink(tmp)
                    except OSError:
                        pass
            if sha256_file(src) != e["before_sha256"]:
                raise Halt("復元後の照合に失敗しました: %s" % e["relative_path"])
            e["restored_sha256_match"] = True
            e["status"] = "restored"
            restored += 1
            print("  ✓ 戻しました %s" % e["relative_path"])
            m["mode"] = "restore"
            m["restored_at"] = now_iso()
            write_json(args.manifest, m)
    print("\n%d 本を元に戻しました。処理前と同じ中身であることを照合しています。" % restored)
    if moved:
        # 退避したときだけ言う。毎回言うと、残骸が出ていない時まで
        # 「何か残っている」と思わせてしまう
        print("\n次のファイルは、この道具が書いたものと確認できなかったので"
              "上書きせず横に残しました。中身を見て、不要なら削除してください:")
        for n in moved:
            print("  - %s" % n)
    else:
        print("処理後のファイルは残していません（フォルダは処理前の本数に戻っています）。")
    return 0


def cmd_commit(args):
    if args.confirm != "DELETE_IMAGE_BACKUP_IRREVERSIBLY":
        raise Halt("--confirm DELETE_IMAGE_BACKUP_IRREVERSIBLY が要ります。何も消していません")
    m = load_manifest(args.manifest, getattr(args, "expect_root", None))
    if not m.get("verified_at"):
        raise Halt("先に verify を通してください。verify 済みの記録だけを受け付けます")
    bdir = require_backup_dir(m, "消せるのは、apply で作ったバックアップだけです。")
    root = m["root"]
    rb = os.path.realpath(bdir)
    if rb == root or root.startswith(rb + os.sep) or rb.startswith(root + os.sep):
        raise Halt("バックアップ先が対象フォルダと重なっています。消しません")

    if any(e["status"] == "replacing" for e in m["files"]):
        raise Halt("置換の途中で中断された記録が残っています。先に restore してください。1件も消しません")

    # すでに消し終えたものは対象から外す。
    # 外さないと、中断したあとにもう一度 commit を打った人が
    # 「バックアップがありません。1件も消しません」で止まって、片づけを終えられない。(v2-B)
    targets = [e for e in m["files"]
               if e["status"] == "changed" and e.get("backup_path")
               and not e.get("backup_committed")]
    already = sum(1 for e in m["files"] if e.get("backup_committed"))
    if not targets:
        if already:
            print("控えはすでに全部消してあります（%d 本）。消すものは残っていません。" % already)
            if m.get("mode") != "commit":   # 中断で committing のまま残っていた分を締める
                m["mode"] = "commit"
                m["committed_at"] = m.get("committed_at") or now_iso()
                write_json(args.manifest, m)
        else:
            print("消すものがありません。")
        return 0

    # ---- 全件を先に検算する。1件でも駄目なら1件も消さない (P0-6) ----
    plan = []
    total = 0
    for e in targets:
        b = safe_join(bdir, e["backup_path"], "バックアップ先")
        if not os.path.exists(b):
            raise Halt("バックアップがありません。1件も消しません: %s" % b)
        if os.path.islink(b) or not stat.S_ISREG(os.lstat(b).st_mode):
            raise Halt("バックアップが通常ファイルではありません。1件も消しません: %s" % b)
        if sha256_file(b) != e["backup_sha256"]:
            raise Halt("記録と一致しないバックアップがあります。1件も消しません: %s" % b)
        total += os.path.getsize(b)
        plan.append((e, b))

    print("== これから消します。戻せなくなります ==")
    print("  場所      : %s" % bdir)
    print("  本数      : %d" % len(plan))
    print("  占有量    : %s" % human(total))
    print("  消したあと、取り除いた画像データは復元できません。")

    # ---- ここから先は検算済みのものだけを消す ----
    # 1本消すごとに記録へ書く。apply が置換のたびに書いているのと同じ形。(v2-B)
    #
    # なぜ最後にまとめて書かないか:
    #   commit は唯一、戻せない操作。ここだけ最後にまとめて書いていると、
    #   途中で電源が落ちたときに「控えは消えているのに、記録は消す前のまま」になる。
    #   そのあと verify を打つと、自分で消した控えが「異常」として出て、
    #   事故で消えたのか自分で消したのかを利用者が判別できない。
    m["mode"] = "committing"
    m["commit_started_at"] = now_iso()
    write_json(args.manifest, m)

    deleted = 0
    touched_dirs = set()
    for e, b in plan:
        os.unlink(b)
        e["backup_committed"] = True
        write_json(args.manifest, m)   # 消した直後に記録する
        touched_dirs.add(os.path.dirname(b))
        deleted += 1

    # 自分が消した結果として空になったフォルダだけを片づける。
    # バックアップ先にもとからあった他人の空フォルダには触らない。
    for d in sorted(touched_dirs, key=len, reverse=True):
        while d != rb and d.startswith(rb + os.sep):
            try:
                if os.listdir(d):
                    break
                os.rmdir(d)
            except OSError:
                break
            d = os.path.dirname(d)

    m["mode"] = "commit"
    m["committed_at"] = now_iso()
    write_json(args.manifest, m)
    print("\n%d 本のバックアップを消しました（%s ぶんの空き）。" % (deleted, human(total)))
    return 0


# ---------------------------------------------------------------------------
# self-test
# ---------------------------------------------------------------------------

def check_selftest_workdir(workdir):
    """
    self-test の作業場として使ってよいかだけを判定する。ここでは1つも作らない。(P0-7)

    判定と作成を分けてあるのは、この判定そのものを安全に試験できるようにするため。
    （作成まで含んでいると、判定を壊した状態の試験が実データの置き場を作ってしまう）
    """
    if os.path.islink(workdir):
        raise Halt("作業場が symlink です。拒否します: %s" % workdir)
    base = _stable_realpath(workdir)

    # 1) 実データの置き場（およびその配下）は作業場にできない。
    #    ここを許すと、作り物のつもりで本物のログを処理してしまう。
    for name in ("~/.codex", "~/.claude", "~/Library", "~/Documents",
                 "~/Desktop", "~/Downloads"):
        f = _stable_realpath(name)
        if base == f or base.startswith(f + os.sep):
            raise Halt("そこは作業場に使えません（実データの置き場です）: %s" % workdir)

    # 2) ホーム直下そのもの・ルートも拒否
    if base in (_stable_realpath("~"), os.path.abspath(os.sep)):
        raise Halt("そこは作業場に使えません: %s" % workdir)

    # 3) 空のフォルダか、まだ無い場所だけ。既存の中身の横で作り物を作らない。
    if os.path.exists(base):
        if not os.path.isdir(base):
            raise Halt("作業場がフォルダではありません: %s" % workdir)
        if os.listdir(base):
            raise Halt("作業場が空ではありません。空のフォルダを指定してください: %s" % workdir)
    return base


def cmd_self_test(args):
    """同梱の作り物だけで一周する。実セッションは一切探さない。"""
    from fixtures import build_fixtures  # 同梱

    if args.workdir:
        base = check_selftest_workdir(args.workdir)
        if not os.path.exists(base):
            os.makedirs(base)
    else:
        base = tempfile.mkdtemp(prefix="kesazu-selftest-")

    root = os.path.join(base, "sessions")
    rep = os.path.join(base, "report")
    bak = os.path.join(base, "backup")
    build_fixtures(root)
    print("作り物の置き場: %s" % root)

    class A(object):
        pass
    if codex_running() is True:
        print("※ Codex は起動中ですが、この検査は temp に作った作り物のログだけを見るので、"
              "そのまま続けます（本物のログには触れません）。")
    a = A(); a.root = root; a.report_dir = rep; a.synthetic = True
    cmd_diagnose(a)
    a.backup_dir = bak; a.confirm = "REMOVE_EMBEDDED_IMAGES"
    cmd_apply(a)
    b = A(); b.manifest = os.path.join(rep, MANIFEST_NAME); b.synthetic = True
    rc = cmd_verify(b)
    b.confirm = "RESTORE_ORIGINALS"
    cmd_restore(b)
    print("\nself-test 終了: %s" % ("OK" if rc == 0 else "NG"))
    return rc


# ---------------------------------------------------------------------------

def main(argv=None):
    p = argparse.ArgumentParser(
        prog=TOOL_NAME,
        description="Codex の会話ログから、埋め込み画像データだけを取り除きます（会話テキストは残します）。")
    sub = p.add_subparsers(dest="cmd")

    d = sub.add_parser("diagnose", help="読むだけ。何が取り除けるか調べます")
    d.add_argument("--root", required=True)
    d.add_argument("--report-dir", required=True)
    d.set_defaults(func=cmd_diagnose)

    a = sub.add_parser("apply", help="実際に取り除きます（バックアップを取ってから）")
    a.add_argument("--root", required=True)
    a.add_argument("--report-dir", required=True)
    a.add_argument("--backup-dir", required=True)
    a.add_argument("--confirm", default="")
    a.set_defaults(func=cmd_apply)

    v = sub.add_parser("verify", help="処理後のファイルと記録を照合します")
    v.add_argument("--manifest", required=True)
    v.add_argument("--expect-root", default=None, help="記録の対象フォルダと一致するか確かめます（任意）")
    v.set_defaults(func=cmd_verify)

    r = sub.add_parser("restore", help="バックアップから元に戻します")
    r.add_argument("--manifest", required=True)
    r.add_argument("--expect-root", default=None, help="記録の対象フォルダと一致するか確かめます（任意）")
    r.add_argument("--confirm", default="")
    r.set_defaults(func=cmd_restore)

    c = sub.add_parser("commit", help="バックアップを消します（戻せなくなります）")
    c.add_argument("--manifest", required=True)
    c.add_argument("--expect-root", default=None, help="記録の対象フォルダと一致するか確かめます（任意）")
    c.add_argument("--confirm", default="")
    c.set_defaults(func=cmd_commit)

    s = sub.add_parser("self-test", help="同梱の作り物だけで一周します")
    s.add_argument("--workdir", default=None)
    s.set_defaults(func=cmd_self_test)

    args = p.parse_args(argv)
    if not getattr(args, "func", None):
        p.print_help()
        return 0
    try:
        return args.func(args)
    except Halt as e:
        eprint("停止しました: %s" % e)
        return 3
    except KeyboardInterrupt:
        eprint("\n中断されました。記録(manifest.json)に、どこまで進んだかが残っています。\n"
               "  verify で状態を確かめてください。「置換中」と出たものは restore で戻せます。")
        return 130


if __name__ == "__main__":
    sys.exit(main())
