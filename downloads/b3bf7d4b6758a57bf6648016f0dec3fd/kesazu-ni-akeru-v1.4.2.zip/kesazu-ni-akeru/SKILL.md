---
name: kesazu-ni-akeru
description: Codexの会話ログ(.jsonl)から埋め込み画像データだけを取り除いて容量を回収する。会話テキストは残す。「Codexのログが重い」「~/.codex/sessionsが膨らんだ」「ディスクの空きがない」「AIのログで容量が食われている」と言われたときに使う。macOS・手動実行のみ。
---

# 消さずに空ける（kesazu-ni-akeru）

Codex の会話ログから、既知の形に入っている**埋め込み画像データだけ**を取り除く。
会話テキストは残す。処理前後で**画像以外のバイト列が一致**したことを照合して記録に残す。

同梱の `README.md` が利用者向けの説明。ここは**あなた（AI）が実行するときの手順**。

## 絶対に守ること

1. **`diagnose` を飛ばして `apply` しない。** 必ず読むだけの診断から始める
2. **`--backup-dir` を利用者に決めてもらう前に `apply` しない。**
   同じ内蔵ディスクを指定すると `commit` するまで空きは増えない。これを必ず先に伝える
3. **`commit` は、利用者が「戻せなくなってよい」と明示してから**しか実行しない。
   `verify` を通し、**利用者が Codex で古い会話を目で見て確かめた**あとに限る
4. **HOLD されたファイルを、なんとかして処理しようとしない。**
   HOLD は失敗ではなく設計。理由をそのまま利用者に伝える
5. **回収量を約束しない。** 「必ず◯GB空きます」は言わない。「回収量は環境によって異なります」を添える
6. **画面の見え方で、成否を判断しない・させない。**
   処理後も Codex の画面では画像が見えたままの場合がある（理由は特定できていない）。
   成否は `verify` の照合結果と、処理前後のファイルサイズで利用者に示す

## 手順

```bash
# 0. まず作り物で一周（本物のログは見ない）
python3 kesazu_ni_akeru.py self-test

# 1. 読むだけ
python3 kesazu_ni_akeru.py diagnose --root ~/.codex/sessions --report-dir <報告先>

# 2. ここで利用者に伝える:
#    - 処理できる本数と見込み回収量
#    - 触らないもの（HOLD）と理由
#    - バックアップ先を「外付け」にするか「同じディスク」にするか
#      （同じディスクなら commit まで空きは増えない）

# 3. Codex を終了してもらってから
python3 kesazu_ni_akeru.py apply --root ~/.codex/sessions --report-dir <報告先> \
    --backup-dir <バックアップ先> --confirm REMOVE_EMBEDDED_IMAGES

# 4. 照合し、利用者に Codex で古い会話を開いて確かめてもらう
python3 kesazu_ni_akeru.py verify --manifest <報告先>/manifest.json

# 5a. 戻す
python3 kesazu_ni_akeru.py restore --manifest <報告先>/manifest.json --confirm RESTORE_ORIGINALS
# 5b. バックアップを消す（利用者の明示的な同意があるときだけ）
python3 kesazu_ni_akeru.py commit --manifest <報告先>/manifest.json \
    --confirm DELETE_IMAGE_BACKUP_IRREVERSIBLY
```

## 止まったときの読み方

| 出力 | あなたがすること |
|---|---|
| `Codex が起動中です` | 利用者に終了を頼む。自分で kill しない |
| `すでに実行中です (lock: …)` | 二重起動。もう一方の終了を待つ。lock ファイルを勝手に消さない |
| `既知でない場所に画像データらしきものが…` | **Codex の形式が変わった可能性**。処理を進めず、その旨を報告する |
| `空き容量が足りません` | バックアップ先を外付けに変えてもらう |
| `診断のあとで中身が変わっています` | Codex が動いた。`diagnose` からやり直す |
| `検証対象がありません（0 本を再検証）` | **「一致した」ではない。** 照合できるものが1本も無い。理由（未 apply／対象0本／全部失敗）を読んで利用者に伝える。**`commit` へ進めない** |

## 範囲

- **対象のログ**: macOS の Codex（`~/.codex/sessions` の `.jsonl`）
- **動かす側**: Claude Code でも Codex でもよい（`SKILL.md` / `AGENTS.md` の両方を同梱）
- **対象外**: Windows・自動実行・Codex 以外のログ（Claude Code / Antigravity のログは対象外）
- 依存: Python 3.9 標準ライブラリのみ

## 自己点検

```bash
python3 test_kesazu.py     # 全103件（別ボリューム試験T24だけは環境依存でskip）
```
