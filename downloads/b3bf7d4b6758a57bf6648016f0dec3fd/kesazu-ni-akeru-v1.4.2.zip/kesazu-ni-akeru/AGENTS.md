# AGENTS.md — 消さずに空ける（kesazu-ni-akeru）

Codex がこのフォルダを読んだときの動き方。
Claude Code 用の `SKILL.md` と**同じ中身・同じ順番**にしてある。**どちらから動かしても同じ手順**になる。

## いつ使うか

利用者がこう言ったとき:

- 「Codex のログが重い」「`~/.codex/sessions` が膨らんだ」
- 「ディスクの空きがない」「AI のログで容量が食われている」

## 何をするものか

Codex の会話ログ（`.jsonl`）から、**既知の形に入っている埋め込み画像データだけ**を取り除く。
会話テキストは残す。処理前後で**画像以外のバイト列が一致**したことを照合して記録する。

## 絶対に守ること

1. **`diagnose` を飛ばして `apply` しない。** 必ず読むだけの診断から始める
2. **`--backup-dir` を利用者に決めてもらう前に `apply` しない。**
   同じ内蔵ディスクを指定すると `commit` するまで空きは増えない。**これを先に伝える**
3. **`commit` は、利用者が「戻せなくなってよい」と明示してから**しか実行しない。
   `verify` を通し、**利用者が Codex で古い会話を目で見て確かめた**あとに限る
4. **HOLD されたファイルを、なんとかして処理しようとしない。** HOLD は失敗ではなく設計
5. **回収量を約束しない。**「回収量は環境によって異なります」を添える
6. **画面の見え方で、成否を判断しない・させない。**
   処理後も Codex の画面では画像が見えたままの場合がある（理由は特定できていない）。
   成否は `verify` の照合結果と、処理前後のファイルサイズで利用者に示す

## 手順

```bash
python3 kesazu_ni_akeru.py self-test
python3 kesazu_ni_akeru.py diagnose --root ~/.codex/sessions --report-dir <報告先>
# ここで利用者に「処理できる本数・見込み回収量・触らないもの・バックアップ先」を伝えて止まる
python3 kesazu_ni_akeru.py apply --root ~/.codex/sessions --report-dir <報告先> \
    --backup-dir <バックアップ先> --confirm REMOVE_EMBEDDED_IMAGES
python3 kesazu_ni_akeru.py verify --manifest <報告先>/manifest.json
# 利用者に Codex で古い会話を開いて確かめてもらってから、どちらか
python3 kesazu_ni_akeru.py restore --manifest <報告先>/manifest.json --confirm RESTORE_ORIGINALS
python3 kesazu_ni_akeru.py commit  --manifest <報告先>/manifest.json --confirm DELETE_IMAGE_BACKUP_IRREVERSIBLY
```

## 自己点検

```bash
python3 test_kesazu.py     # 全103件（別ボリューム試験T24だけは環境依存でskip）
```

## Codex 向けの出力ルール

（`AGENTS.md` の調教が要る、というブックマークの指摘に合わせる）

- **作成・変更したファイルのパスを必ず明示する**（報告先・バックアップ先・manifest の実パス）
- **いきなり実行しない。** まず `diagnose` の結果を出して、次に何をするかを述べて止まる
- **処理した本数・触らなかった本数とその理由**を、毎回一覧で出す
- 分からないことがあれば質問する。**推測で進めない**

## 止まったときの読み方

| 出力 | すること |
|---|---|
| `Codex が起動中です` | 利用者に終了を頼む。**自分で kill しない** |
| `すでに実行中です (lock: …)` | 二重起動。lock ファイルを勝手に消さない |
| `既知でない場所に画像データらしきものが…` | **Codex の形式が変わった可能性**。進めずに報告する |
| `空き容量が足りません` | バックアップ先を外付けに変えてもらう |
| `診断のあとで中身が変わっています` | Codex が動いた。`diagnose` からやり直す |
| `検証対象がありません（0 本を再検証）` | **「一致した」ではない。** 照合できるものが1本も無い。理由（未 apply／対象0本／全部失敗）を読んで利用者に伝える。**`commit` へ進めない** |

## 範囲

- **対象のログ**: macOS の Codex（`~/.codex/sessions` の `.jsonl`）
- **動かす側**: Codex でも Claude Code でもよい（`AGENTS.md` / `SKILL.md` の両方を同梱）
- **対象外**: Windows・自動実行・Codex 以外のログ
- 依存: Python 3.9 標準ライブラリのみ
