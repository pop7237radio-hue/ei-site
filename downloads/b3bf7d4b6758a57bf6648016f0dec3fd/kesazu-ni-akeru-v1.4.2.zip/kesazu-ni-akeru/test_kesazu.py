# -*- coding: utf-8 -*-
"""
自動試験 全103件（02_試験マトリクス.md の T01〜T28 ＋ 枝番・CLI/ガード試験・敵対入力22件
　　　　　　　　＋v1.4.0 の「控えの置き場に引きずられない復元」3件）

  python3 test_kesazu.py

実セッションは一切見ない。同梱 fixtures.py の作り物だけで完結する。
"""

import io
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import unittest
import contextlib

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import fixtures  # noqa: E402
import kesazu_ni_akeru as K  # noqa: E402


class Args(object):
    def __init__(self, **kw):
        self.__dict__.update(kw)


@contextlib.contextmanager
def quiet():
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        yield buf


def sha_tree(root):
    out = {}
    for dp, dn, fn in os.walk(root):
        for n in sorted(fn):
            p = os.path.join(dp, n)
            if os.path.islink(p):
                continue
            out[os.path.relpath(p, root)] = K.sha256_file(p)
    return out


class Base(unittest.TestCase):
    def setUp(self):
        self.base = tempfile.mkdtemp(prefix="kesazu-t-")
        self.root = os.path.join(self.base, "sessions")
        self.rep = os.path.join(self.base, "report")
        self.bak = os.path.join(self.base, "backup")
        fixtures.build_fixtures(self.root)
        # 試験中は「Codex は動いていない」ことにする。
        # 製品コードの安全弁は触らない（弁そのものは T_CodexGuard で別に検査する）。
        self._real_codex_running = K.codex_running
        K.codex_running = lambda: False

    def tearDown(self):
        K.codex_running = self._real_codex_running
        shutil.rmtree(self.base, ignore_errors=True)

    def diagnose(self, root=None, rep=None):
        with quiet() as b:
            K.cmd_diagnose(Args(root=root or self.root, report_dir=rep or self.rep))
        return json.load(open(os.path.join(rep or self.rep, K.MANIFEST_NAME))), b.getvalue()

    def apply(self, confirm="REMOVE_EMBEDDED_IMAGES", bak=None):
        with quiet() as b:
            K.cmd_apply(Args(root=self.root, report_dir=self.rep,
                             backup_dir=bak or self.bak, confirm=confirm))
        return json.load(open(os.path.join(self.rep, K.MANIFEST_NAME))), b.getvalue()

    def mpath(self):
        return os.path.join(self.rep, K.MANIFEST_NAME)

    def entry(self, m, name):
        for e in m["files"]:
            if os.path.basename(e["relative_path"]) == name:
                return e
        return None

    def full_cycle(self):
        self.diagnose()
        return self.apply()


class T_Diagnose(Base):
    def test_T11_diagnose_changes_nothing(self):
        before = sha_tree(self.root)
        self.diagnose()
        self.assertEqual(before, sha_tree(self.root), "diagnose がファイルを変えた")

    def test_T08_non_jsonl_untouched(self):
        m, _ = self.diagnose()
        names = [os.path.basename(e["relative_path"]) for e in m["files"]]
        for n in ("t08_notes.txt", "t08_cache.db", "t08_noext"):
            self.assertNotIn(n, names, "%s を対象にしてしまった" % n)

    def test_T09_symlink_rejected(self):
        outside = os.path.join(self.base, "outside.jsonl")
        shutil.copy(os.path.join(self.root, "t02_one_image.jsonl"), outside)
        fixtures.build_symlink_fixture(self.root, outside)
        before = K.sha256_file(outside)
        self.full_cycle()
        m = json.load(open(self.mpath()))
        names = [os.path.basename(e["relative_path"]) for e in m["files"]]
        self.assertNotIn("t09_link.jsonl", names, "symlink を対象にした")
        self.assertEqual(before, K.sha256_file(outside), "root 外のファイルが変わった")

    def test_T09b_root_symlink_rejected(self):
        link = os.path.join(self.base, "rootlink")
        os.symlink(self.root, link)
        with self.assertRaises(K.Halt):
            K.cmd_diagnose(Args(root=link, report_dir=self.rep))

    def test_T06_broken_json_holds_file(self):
        m, _ = self.diagnose()
        e = self.entry(m, "t06_broken.jsonl")
        self.assertEqual(e["status"], "held")
        self.assertIn("JSON", e["reason"])

    def test_T07_unknown_location_holds(self):
        m, _ = self.diagnose()
        e = self.entry(m, "t07_unknown.jsonl")
        self.assertEqual(e["status"], "held")
        self.assertGreater(e["unknown_hits"], 0)

    def test_T05_text_datauri_is_not_a_candidate(self):
        m, _ = self.diagnose()
        e = self.entry(m, "t05_text_datauri.jsonl")
        self.assertEqual(e["embedded_images"], 0, "本文中の文字列を画像と誤認した")
        self.assertEqual(e["unknown_hits"], 0, "既知の本文フィールドを未知扱いした")
        self.assertEqual(e["status"], "skipped")

    def test_T10_recent_file_held(self):
        m, _ = self.diagnose()
        e = self.entry(m, "t10_recent.jsonl")
        self.assertEqual(e["status"], "held")
        self.assertIn("24時間", e["reason"])

    def test_T20_report_inside_root_rejected(self):
        with self.assertRaises(K.Halt):
            K.cmd_diagnose(Args(root=self.root, report_dir=os.path.join(self.root, "rep")))

    def test_T13_double_run_blocked(self):
        os.makedirs(self.rep, exist_ok=True)
        with K.Lock(self.rep):
            with self.assertRaises(K.Halt):
                K.cmd_diagnose(Args(root=self.root, report_dir=self.rep))


class T_Apply(Base):
    def test_T01_normal_conversation_untouched(self):
        # 買った人の大半のログがこれ。画像がまったく無い会話は1バイトも触らない。
        p = os.path.join(self.root, "t01_normal.jsonl")
        before = K.sha256_file(p)
        m, _ = self.diagnose()
        e = self.entry(m, "t01_normal.jsonl")
        self.assertEqual(e["embedded_images"], 0, "画像のない会話から画像を見つけたことにしている")
        self.assertEqual(e["status"], "skipped", "画像のない会話を処理対象にしてしまった")
        self.full_cycle()
        self.assertEqual(before, K.sha256_file(p), "会話だけのログを書き換えてしまった")

    def test_T02_single_image_only_image_changes(self):
        m0, _ = self.diagnose()
        b0 = self.entry(m0, "t02_one_image.jsonl")
        m, _ = self.apply()
        e = self.entry(m, "t02_one_image.jsonl")
        self.assertEqual(e["status"], "changed")
        self.assertEqual(e["canonical_non_image_sha256_after"],
                         b0["canonical_non_image_sha256_before"])
        self.assertLess(e["after_size"], e["before_size"])

    def test_T03_multiple_images_in_one_line(self):
        self.diagnose()
        m, _ = self.apply()
        e = self.entry(m, "t03_multi_image.jsonl")
        self.assertEqual(e["embedded_images"], 3, "同一行の3枚を数えられていない")
        self.assertEqual(e["status"], "changed")
        raw = open(os.path.join(self.root, "t03_multi_image.jsonl"), encoding="utf-8").read()
        self.assertNotIn("data:image/", raw)
        self.assertEqual(raw.count(K.MARKER_PREFIX), 3)

    def test_T04_attached_generated_counted(self):
        m, _ = self.diagnose()
        e = self.entry(m, "t04_attached.jsonl")
        self.assertEqual(e["embedded_images"], 1, "output 経由の画像を候補にできていない")

    def test_T05_text_bytes_unchanged_after_apply(self):
        before = K.sha256_file(os.path.join(self.root, "t05_text_datauri.jsonl"))
        self.full_cycle()
        after = K.sha256_file(os.path.join(self.root, "t05_text_datauri.jsonl"))
        self.assertEqual(before, after, "本文中の data URI を書き換えてしまった")

    def test_T06_T07_T10_held_files_unchanged(self):
        names = ["t06_broken.jsonl", "t07_unknown.jsonl", "t10_recent.jsonl"]
        before = {n: K.sha256_file(os.path.join(self.root, n)) for n in names}
        self.full_cycle()
        for n in names:
            self.assertEqual(before[n], K.sha256_file(os.path.join(self.root, n)),
                             "HOLD したはずの %s が変わった" % n)

    def test_T12_source_changed_after_diagnose(self):
        self.diagnose()
        p = os.path.join(self.root, "t02_one_image.jsonl")
        with open(p, "a", encoding="utf-8") as fh:
            fh.write('{"type":"response_item","payload":{"type":"message"}}\n')
        m, _ = self.apply()
        e = self.entry(m, "t02_one_image.jsonl")
        self.assertEqual(e["status"], "failed")
        self.assertIn("変わって", e["reason"])

    def test_T16_line_json_canonical_all_match(self):
        m0, _ = self.diagnose()
        m, _ = self.apply()
        for e in m["files"]:
            if e["status"] != "changed":
                continue
            b0 = self.entry(m0, os.path.basename(e["relative_path"]))
            self.assertEqual(e["line_count_after"], b0["line_count_before"])
            self.assertEqual(e["json_errors_after"], b0["json_errors_before"])
            self.assertEqual(e["canonical_non_image_sha256_after"],
                             b0["canonical_non_image_sha256_before"])

    def test_T17_reapply_changes_nothing(self):
        self.full_cycle()
        snap = sha_tree(self.root)
        rep2 = os.path.join(self.base, "report2")
        m2, _ = self.diagnose(rep=rep2)
        # HOLD したファイル（壊れたJSON・直近更新）は触っていないので画像が残っていて当然。
        # 「処理したものを、また候補にしていないか」だけを見る。
        done = {e["relative_path"] for e in json.load(open(self.mpath()))["files"]
                if e["status"] == "changed"}
        again = [e for e in m2["files"]
                 if e["relative_path"] in done and e["embedded_images"] > 0]
        self.assertEqual(again, [], "処理済みのファイルをまた候補にした")
        self.assertEqual([e for e in m2["files"] if e["status"] == "candidate"], [],
                         "2回目に処理対象が残っている")
        with quiet():
            K.cmd_apply(Args(root=self.root, report_dir=rep2,
                             backup_dir=os.path.join(self.base, "backup2"),
                             confirm="REMOVE_EMBEDDED_IMAGES"))
        self.assertEqual(snap, sha_tree(self.root), "2回目の apply でファイルが変わった")

    def test_T21_japanese_emoji_preserved(self):
        p = os.path.join(self.root, "t21_jp.jsonl")
        before = json.loads(open(p, encoding="utf-8").read().strip())
        self.full_cycle()
        after = json.loads(open(p, encoding="utf-8").read().strip())
        bt = [c for c in before["payload"]["content"] if c["type"] == "input_text"]
        at = [c for c in after["payload"]["content"] if c["type"] == "input_text"]
        self.assertEqual(bt, at, "日本語・絵文字・エスケープが変わった")
        self.assertEqual(open(p, "rb").read().count(b"\n"), 1, "改行が増減した")

    def test_T22_mode_and_mtime_preserved(self):
        p = os.path.join(self.root, "t02_one_image.jsonl")
        os.chmod(p, 0o640)
        # 秒の小数では表しきれない端数を、わざと入れておく。
        # ここが丸い値のままだと、小数に直しても値が変わらないので、
        # 「丸めで下の桁が落ちる」という壊れ方を試験が見逃す（実際に見逃していた）。
        ns = (int(time.time()) - 3 * 86400) * 1000000000 + 123456789
        os.utime(p, ns=(ns, ns))
        st0 = os.stat(p)
        self.full_cycle()
        st1 = os.stat(p)
        self.assertEqual(stat.S_IMODE(st0.st_mode), stat.S_IMODE(st1.st_mode))
        # 1ミリ秒の許容だと、秒を小数で渡したときの丸めを見逃す。ナノ秒でぴったり見る。
        self.assertEqual(st0.st_mtime_ns, st1.st_mtime_ns,
                         "処理のあとで更新日時がずれた")

    def test_T23_same_volume_warns_no_real_gain(self):
        self.diagnose()
        _, out = self.apply()
        self.assertIn("同じディスク", out)
        self.assertIn("commit", out)

    def test_T24_other_volume_message(self):
        self.diagnose()
        m, out = self.apply()
        if m["backup_same_volume"]:
            self.skipTest("この環境では別ボリュームを用意できない（B工程 Mac mini で確認）")
        self.assertIn("空きが増え", out)

    def test_T14_not_enough_space(self):
        self.diagnose()
        orig = K.shutil.disk_usage

        class U(object):
            total = free = used = 1024

        K.shutil.disk_usage = lambda p: U()
        try:
            before = sha_tree(self.root)
            with self.assertRaises(K.Halt):
                self.apply()
            self.assertEqual(before, sha_tree(self.root), "容量不足なのに書き換えた")
        finally:
            K.shutil.disk_usage = orig

    def test_T15_interrupt_leaves_original(self):
        self.diagnose()
        p = os.path.join(self.root, "t02_one_image.jsonl")
        before = K.sha256_file(p)
        orig = K.make_marker

        def boom(v):
            raise KeyboardInterrupt()

        K.make_marker = boom
        try:
            with quiet():
                try:
                    self.apply()
                except KeyboardInterrupt:
                    pass
        finally:
            K.make_marker = orig
        self.assertEqual(before, K.sha256_file(p), "中断で原本が壊れた")
        leftovers = [n for n in os.listdir(self.root) if n.startswith(".kesazu-")]
        self.assertEqual(leftovers, [], "一時ファイルが残った: %r" % leftovers)

    def test_apply_requires_confirm(self):
        self.diagnose()
        before = sha_tree(self.root)
        with self.assertRaises(K.Halt):
            self.apply(confirm="")
        self.assertEqual(before, sha_tree(self.root))

    def test_apply_requires_diagnose_first(self):
        with self.assertRaises(K.Halt):
            self.apply()


class T_VerifyRestoreCommit(Base):
    def setUp(self):
        Base.setUp(self)
        self.before = sha_tree(self.root)
        self.full_cycle()

    def test_T18_restore_exact(self):
        with quiet():
            rc = K.cmd_verify(Args(manifest=self.mpath()))
            self.assertEqual(rc, 0)
            K.cmd_restore(Args(manifest=self.mpath(), confirm="RESTORE_ORIGINALS"))
        m = json.load(open(self.mpath()))
        checked = 0
        for e in m["files"]:
            if e["status"] not in ("changed", "restored"):
                continue
            p = os.path.join(self.root, e["relative_path"])
            self.assertEqual(K.sha256_file(p), e["before_sha256"],
                             "復元後が処理前と一致しない: %s" % e["relative_path"])
            checked += 1
        self.assertGreater(checked, 0, "復元を1本も確かめていない（試験が素通りしている）")

    def test_v3A_restore_leaves_no_litter(self):
        """
        戻したあと、フォルダが処理前と『同じ本数・同じ中身』に帰ること。

        なぜ要るか: T18 は戻した1本1本の中身しか見ていなかったので、
        『戻したのに処理後のファイルが横に残り、ディスクが始める前より減る』
        という状態を、76件の試験が1つも捕まえられなかった（2026-08-05 実測で発覚。
        実ログ複製で 5本1.6MB → 8本2.3MB に増えていた）。
        空けるための道具が容量を増やして終わるのは、約束と逆。
        """
        with quiet():
            K.cmd_restore(Args(manifest=self.mpath(), confirm="RESTORE_ORIGINALS"))
        after = sha_tree(self.root)
        extra = sorted(set(after) - set(self.before))
        self.assertEqual(extra, [], "戻したのに余計なファイルが残っている: %s" % extra)
        self.assertEqual(after, self.before, "戻したあとのフォルダが処理前と違う")

    def test_v3B_restore_keeps_unknown_file_aside(self):
        """
        逆に、置いてあるものが『この道具が書いたもの』と言い切れないときは、
        上書きせず横に残すこと（残骸を減らすために安全側を捨てていないか）。
        """
        m = json.load(open(self.mpath()))
        e = [x for x in m["files"] if x["status"] == "changed"][0]
        p = os.path.join(self.root, e["relative_path"])
        with open(p, "ab") as fh:                 # Codex が書き足した状況を作る
            fh.write('{"type":"message","content":"あとから足された行"}\n'.encode("utf-8"))
        mine = K.sha256_file(p)
        with quiet():
            K.cmd_restore(Args(manifest=self.mpath(), confirm="RESTORE_ORIGINALS"))
        aside = [n for n in os.listdir(os.path.dirname(p))
                 if n.startswith(os.path.basename(p) + ".kesazu-preexisting-")]
        self.assertEqual(len(aside), 1, "見覚えのないファイルを黙って消した")
        self.assertEqual(K.sha256_file(os.path.join(os.path.dirname(p), aside[0])), mine,
                         "横に残したものの中身が変わっている")
        self.assertEqual(K.sha256_file(p), e["before_sha256"], "原本が戻っていない")

    def test_v4A_restore_uses_recorded_mode_not_backup(self):
        """
        控えの置き場が権限を持てない形式（Windows と共用の外付け＝ExFAT など）でも、
        戻したあとの権限が原本と同じであること。

        なぜ要るか: restore は控えから copystat していたので、
        控えが ExFAT にあると 640 の原本が 700 になって戻っていた（2026-08-05 実測）。
        「控えは別のディスクへ」と勧めている以上、外付けはいちばん当たりやすい経路で、
        そこがちょうど、この道具が唯一メタデータを落とす場所だった。
        ここでは実際の外付けを使わず、控えの側だけを同じ壊れ方にして再現する。
        """
        m = json.load(open(self.mpath()))
        e = [x for x in m["files"] if x["status"] == "changed"][0]
        b = os.path.join(m["backup_dir"], e["backup_path"])
        self.assertTrue(os.path.exists(b), "控えが無い（試験が素通りしている）")
        os.chmod(b, 0o700)                       # ExFAT 上での見え方をまねる
        with quiet():
            K.cmd_restore(Args(manifest=self.mpath(), confirm="RESTORE_ORIGINALS"))
        p = os.path.join(self.root, e["relative_path"])
        self.assertEqual(stat.S_IMODE(os.stat(p).st_mode), e["before_mode"],
                         "控えの権限が原本に移ってしまった")

    def test_v4B_restore_uses_recorded_mtime_not_backup(self):
        """
        控えの置き場の時刻の刻みが粗くても（ExFAT は 10ms 単位）、
        戻したあとの更新日時が原本とぴったり同じであること。
        """
        m = json.load(open(self.mpath()))
        e = [x for x in m["files"] if x["status"] == "changed"][0]
        b = os.path.join(m["backup_dir"], e["backup_path"])
        coarse = (e["before_mtime_ns"] // 10000000) * 10000000 - 7000000
        os.utime(b, ns=(coarse, coarse))
        self.assertNotEqual(coarse, e["before_mtime_ns"], "崩せていない（試験が素通りしている）")
        with quiet():
            K.cmd_restore(Args(manifest=self.mpath(), confirm="RESTORE_ORIGINALS"))
        p = os.path.join(self.root, e["relative_path"])
        self.assertEqual(os.stat(p).st_mtime_ns, e["before_mtime_ns"],
                         "控えの粗い時刻が原本に移ってしまった")

    def test_v4C_manifest_records_original_mode_and_mtime(self):
        """
        戻すときの拠り所は控えではなく記録。記録に無ければ、そもそも戻しようがない。
        """
        m = json.load(open(self.mpath()))
        checked = 0
        for e in m["files"]:
            self.assertIsInstance(e.get("before_mode"), int,
                                  "権限を記録していない: %s" % e["relative_path"])
            self.assertIsInstance(e.get("before_mtime_ns"), int,
                                  "更新日時を記録していない: %s" % e["relative_path"])
            checked += 1
        self.assertGreater(checked, 0, "1本も見ていない（試験が素通りしている）")

    def test_T19_tampered_backup_blocks_restore(self):
        m = json.load(open(self.mpath()))
        e = [x for x in m["files"] if x["status"] == "changed"][0]
        b = os.path.join(m["backup_dir"], e["backup_path"])
        with open(b, "ab") as fh:
            fh.write(b"x")
        cur = K.sha256_file(os.path.join(self.root, e["relative_path"]))
        with self.assertRaises(K.Halt):
            with quiet():
                K.cmd_restore(Args(manifest=self.mpath(), confirm="RESTORE_ORIGINALS"))
        self.assertEqual(cur, K.sha256_file(os.path.join(self.root, e["relative_path"])),
                         "改ざん検知したのにファイルを触った")

    def test_restore_requires_confirm(self):
        snap = sha_tree(self.root)
        with self.assertRaises(K.Halt):
            K.cmd_restore(Args(manifest=self.mpath(), confirm=""))
        self.assertEqual(snap, sha_tree(self.root))

    def test_T25_commit_wrong_confirm_keeps_backup(self):
        with quiet():
            K.cmd_verify(Args(manifest=self.mpath()))
        snap = sha_tree(self.bak)
        with self.assertRaises(K.Halt):
            K.cmd_commit(Args(manifest=self.mpath(), confirm="DELETE"))
        self.assertEqual(snap, sha_tree(self.bak), "確認文が違うのにバックアップを触った")

    def test_commit_requires_verify_first(self):
        with self.assertRaises(K.Halt):
            K.cmd_commit(Args(manifest=self.mpath(),
                              confirm="DELETE_IMAGE_BACKUP_IRREVERSIBLY"))

    def test_T26_commit_deletes_only_manifest_backups(self):
        stray = os.path.join(self.bak, "not-ours.bin")
        with open(stray, "wb") as fh:
            fh.write(b"keep me")
        root_snap = sha_tree(self.root)
        with quiet():
            K.cmd_verify(Args(manifest=self.mpath()))
            K.cmd_commit(Args(manifest=self.mpath(),
                              confirm="DELETE_IMAGE_BACKUP_IRREVERSIBLY"))
        self.assertTrue(os.path.exists(stray), "記録に無いファイルを消した")
        self.assertEqual(b"keep me", open(stray, "rb").read())
        self.assertTrue(os.path.isdir(self.bak), "バックアップの親フォルダを消した")
        self.assertEqual(root_snap, sha_tree(self.root), "commit が対象フォルダを変えた")
        m = json.load(open(self.mpath()))
        for e in m["files"]:
            if e["status"] == "changed":
                self.assertFalse(os.path.exists(os.path.join(self.bak, e["backup_path"])))


class T_SelfTestAndCLI(Base):
    def test_T27_self_test_touches_no_real_sessions(self):
        real = os.path.expanduser("~/.codex/sessions")
        before = None
        if os.path.isdir(real):
            before = (len(os.listdir(real)), os.path.getmtime(real))
        wd = os.path.join(self.base, "st")
        with quiet() as b:
            rc = K.cmd_self_test(Args(workdir=wd))
        self.assertEqual(rc, 0)
        self.assertNotIn(os.path.expanduser("~/.codex"), b.getvalue(),
                         "self-test が実セッションのパスに触れた")
        if before is not None:
            self.assertEqual(before, (len(os.listdir(real)), os.path.getmtime(real)),
                             "self-test が実セッションを触った")

    def test_no_args_prints_help_only(self):
        snap = sha_tree(self.root)
        r = subprocess.run([sys.executable, os.path.join(HERE, "kesazu_ni_akeru.py")],
                           capture_output=True, text=True)
        self.assertEqual(r.returncode, 0)
        self.assertIn("usage", r.stdout.lower())
        self.assertEqual(snap, sha_tree(self.root))

    def test_unknown_command_no_write(self):
        snap = sha_tree(self.root)
        r = subprocess.run([sys.executable, os.path.join(HERE, "kesazu_ni_akeru.py"), "nuke"],
                           capture_output=True, text=True)
        self.assertNotEqual(r.returncode, 0)
        self.assertEqual(snap, sha_tree(self.root))

    def test_no_developer_specific_paths(self):
        src = open(os.path.join(HERE, "kesazu_ni_akeru.py"), encoding="utf-8").read()
        for bad in ("/Users/user", "Ei_2nd_Brain", "siroradio"):
            self.assertNotIn(bad, src, "開発者固有の文字列が残っている: %s" % bad)

    def test_no_default_root(self):
        src = open(os.path.join(HERE, "kesazu_ni_akeru.py"), encoding="utf-8").read()
        self.assertNotIn('"--root", default', src)

    def test_version_and_test_count_are_stated_the_same_everywhere(self):
        """版番号と試験件数が、同梱物のあいだで食い違わないこと。

        2026-08-05 に実際に3点が割れた（VERSION 1.0.1 / TOOL_VERSION 1.1.0 /
        README 1.0.1）。人の目で揃えるのをやめて、ここで機械に見張らせる。

        同日さらに、その見張りの外側で本体の冒頭が「v1.1.0 / 全60件」のまま
        残っていた（中身は 1.1.1・70件）。3箇所だけ見ていたのが原因なので、
        「宣言している場所」を全部ここに入れる。買った人が最初に開くのは本体の冒頭。

        件数は数字を書き写さず、実際に集まった試験の数と突き合わせる。
        （書き写す方式だと、試験を足すたびに直す場所が増えてまた食い違う）
        """
        import ast
        import re as _re
        vfile = open(os.path.join(HERE, "VERSION"), encoding="utf-8").read().strip()
        readme = open(os.path.join(HERE, "README.md"), encoding="utf-8").read().splitlines()[0]
        self.assertEqual(vfile, K.TOOL_VERSION,
                         "VERSION ファイルと TOOL_VERSION が違う")
        self.assertIn("v" + K.TOOL_VERSION, readme,
                      "README の見出しの版番号が違う: %r" % readme)

        def docstring_of(name):
            src = open(os.path.join(HERE, name), encoding="utf-8").read()
            return ast.get_docstring(ast.parse(src)) or ""

        main_doc = docstring_of("kesazu_ni_akeru.py")
        self.assertIn("v" + K.TOOL_VERSION, main_doc,
                      "本体の冒頭の説明文の版番号が古い（中身は %s）" % K.TOOL_VERSION)

        actual = unittest.defaultTestLoader.loadTestsFromModule(
            sys.modules[__name__]).countTestCases()
        for label, name in (("本体", "kesazu_ni_akeru.py"), ("試験", "test_kesazu.py")):
            for n in _re.findall(r"全\s*(\d+)\s*件", docstring_of(name)):
                self.assertEqual(
                    int(n), actual,
                    "%s の冒頭が名乗る試験件数 %s 件が、実際に集まった %d 件と違う"
                    % (label, n, actual))


class T_AlreadyProcessed(Base):
    """
    T28（実データで見つけた欠陥・2026-08-05）
    別のツールが先に中身を抜いたログは、既知フィールドに短い残骸が入っている。
    それを「画像」とみなして札に置き換えると、ファイルがかえって大きくなる。
    """

    def _write_residue(self, name):
        p = os.path.join(self.root, name)
        payload = "c3RyaXBwZWQ="  # 短い残骸
        line = json.dumps({"type": "response_item", "payload": {"type": "message", "content": [
            {"type": "input_text", "text": "前に別のツールで処理したログ"},
            {"type": "input_image", "image_url": "data:image/png;base64," + payload},
        ]}}, ensure_ascii=False)
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(line + "\n")
        old = time.time() - 3 * 86400
        os.utime(p, (old, old))
        return p

    def test_T28_residue_not_treated_as_image(self):
        p = self._write_residue("t28_residue.jsonl")
        m, _ = self.diagnose()
        e = self.entry(m, "t28_residue.jsonl")
        self.assertEqual(e["embedded_images"], 0, "残骸を画像として数えた")
        self.assertEqual(e["unknown_hits"], 0, "既知フィールドなのに未知扱いした")
        self.assertEqual(e["tiny_left_alone"], 1)
        self.assertEqual(e["status"], "skipped")

    def test_T28b_file_never_grows(self):
        self._write_residue("t28_residue.jsonl")
        sizes = {n: os.path.getsize(os.path.join(self.root, n))
                 for n in os.listdir(self.root) if n.endswith(".jsonl")}
        self.full_cycle()
        for n, before in sizes.items():
            after = os.path.getsize(os.path.join(self.root, n))
            self.assertLessEqual(after, before, "%s が処理で大きくなった (%d→%d)" % (n, before, after))

    def test_T28c_no_negative_reclaim(self):
        self._write_residue("t28_residue.jsonl")
        m, _ = self.diagnose()
        for e in m["files"]:
            self.assertGreaterEqual(e["reclaimable_bytes"], 0,
                                    "%s の見込み回収量が負" % e["relative_path"])


class T_CodexGuard(Base):
    """安全弁そのものの検査（他の試験では弁を閉じた前提にしているので、ここで別途見る）。"""

    def test_apply_blocked_while_codex_running(self):
        K.codex_running = lambda: False
        self.diagnose()
        K.codex_running = lambda: True
        before = sha_tree(self.root)
        with self.assertRaises(K.Halt):
            self.apply()
        self.assertEqual(before, sha_tree(self.root), "Codex 起動中なのに書き換えた")

    def test_diagnose_holds_while_codex_running(self):
        K.codex_running = lambda: True
        m, out = self.diagnose()
        self.assertIn("起動中", out)
        self.assertEqual([e for e in m["files"] if e["status"] == "candidate"], [])

    def test_guard_reads_real_process_list(self):
        """モックを外した本物の判定が True/False/None のどれかを返すこと。"""
        r = self._real_codex_running()
        self.assertIn(r, (True, False, None))




# ===========================================================================
# v1.1.0: Sol Ultra 敵対検品（2026-08-05）で指摘された P0 7件の回帰試験
#   「直した」ではなく「壊れていたら試験が落ちる」状態にするための追加分。
# ===========================================================================

class T_P0_AdversarialRegression(Base):

    # ---- P0-1 記録(manifest)を信用しすぎる ----------------------------------
    def test_P0_1a_restore_rejects_path_escape(self):
        """記録の relative_path を書き換えても、対象フォルダの外へ復元しない。"""
        self.full_cycle()
        with quiet():
            K.cmd_verify(Args(manifest=self.mpath()))
        outside = os.path.join(self.base, "OUTSIDE.txt")
        with open(outside, "wb") as fh:
            fh.write(b"do-not-touch")
        m = json.load(open(self.mpath()))
        e = [x for x in m["files"] if x["status"] == "changed"][0]
        e["relative_path"] = os.path.join("..", "..", "OUTSIDE.txt")
        json.dump(m, open(self.mpath(), "w"), ensure_ascii=False)

        with self.assertRaises(K.Halt):
            with quiet():
                K.cmd_restore(Args(manifest=self.mpath(), confirm="RESTORE_ORIGINALS"))
        self.assertEqual(b"do-not-touch", open(outside, "rb").read(),
                         "対象フォルダの外へ書き込んだ")

    def test_P0_1b_commit_rejects_backup_path_escape(self):
        """記録の backup_path を書き換えても、バックアップ先の外を消さない。"""
        self.full_cycle()
        with quiet():
            K.cmd_verify(Args(manifest=self.mpath()))
        outside = os.path.join(self.base, "PRECIOUS.txt")
        with open(outside, "wb") as fh:
            fh.write(b"keep")
        m = json.load(open(self.mpath()))
        e = [x for x in m["files"] if x["status"] == "changed"][0]
        e["backup_path"] = os.path.join("..", "..", "PRECIOUS.txt")
        json.dump(m, open(self.mpath(), "w"), ensure_ascii=False)

        with self.assertRaises(K.Halt):
            with quiet():
                K.cmd_commit(Args(manifest=self.mpath(),
                                  confirm="DELETE_IMAGE_BACKUP_IRREVERSIBLY"))
        self.assertTrue(os.path.exists(outside), "バックアップ先の外を消した")
        self.assertEqual(b"keep", open(outside, "rb").read())

    def test_P0_1c_manifest_root_must_match_when_given(self):
        """--expect-root を渡したら、記録の対象フォルダと違えば止まる。"""
        self.full_cycle()
        other = os.path.join(self.base, "other")
        os.makedirs(other)
        with self.assertRaises(K.Halt):
            with quiet():
                K.cmd_verify(Args(manifest=self.mpath(), expect_root=other))

    # ---- P0-2 置換の直前に再確認しない -------------------------------------
    def test_P0_2_append_between_read_and_replace_is_not_lost(self):
        """変換の読み取り後・置換の直前に追記されたら、その1本は書き換えない。"""
        self.diagnose()
        target = os.path.join(self.root, "t02_one_image.jsonl")
        extra = ('{"type":"response_item","payload":{"type":"message",'
                 '"content":[{"type":"input_text","text":"あとから来た発言"}]}}\n'
                 ).encode("utf-8")

        real_convert = K.convert_file

        def racing_convert(src, entry):
            tmp, after = real_convert(src, entry)
            if os.path.basename(src) == "t02_one_image.jsonl":
                with open(src, "ab") as fh:      # 読み取り後に横から追記
                    fh.write(extra)
            return tmp, after

        K.convert_file = racing_convert
        try:
            with quiet():
                K.cmd_apply(Args(root=self.root, report_dir=self.rep,
                                 backup_dir=self.bak, confirm="REMOVE_EMBEDDED_IMAGES"))
        finally:
            K.convert_file = real_convert

        body = open(target, "rb").read()
        self.assertIn(extra.strip(), body, "あとから来た発言が消えた（P0-2の再発）")
        self.assertIn(b"data:image/", body, "追記を検知したのに置換してしまった")
        m = json.load(open(self.mpath()))
        e = self.entry(m, "t02_one_image.jsonl")
        self.assertNotEqual(e["status"], "changed")

    # ---- P0-3 途中で落ちると記録が嘘になる ---------------------------------
    def test_P0_3_crash_during_replace_leaves_truthful_record(self):
        """置換に失敗したら、記録が『changed』と嘘をつかない。"""
        self.diagnose()
        real_replace = os.replace

        def failing_replace(a, b, *args, **kw):
            if str(b).endswith(".jsonl"):
                raise OSError("disk gone")
            return real_replace(a, b, *args, **kw)

        K.os.replace = failing_replace
        try:
            with quiet():
                K.cmd_apply(Args(root=self.root, report_dir=self.rep,
                                 backup_dir=self.bak, confirm="REMOVE_EMBEDDED_IMAGES"))
        finally:
            K.os.replace = real_replace

        m = json.load(open(self.mpath()))
        for e in m["files"]:
            if e["status"] == "changed":
                p = os.path.join(self.root, e["relative_path"])
                self.assertNotIn(b"data:image/", open(p, "rb").read(),
                                 "changed と書いてあるのに画像が残っている（記録が嘘）")
        self.assertTrue(any(e["status"] in ("replacing", "failed") for e in m["files"]),
                        "失敗したのに記録に痕跡がない")
        with quiet():
            rc = K.cmd_verify(Args(manifest=self.mpath()))
        self.assertNotEqual(rc, 0, "中断された記録を verify が見逃した")

    # ---- P0-4 既存バックアップを上書きする ---------------------------------
    def test_P0_4_second_run_does_not_clobber_first_backup(self):
        """同じバックアップ先へ2回流しても、1回目の控えを壊さない。"""
        self.full_cycle()
        m1 = json.load(open(self.mpath()))
        bdir1 = m1["backup_dir"]
        snap1 = sha_tree(bdir1)
        self.assertTrue(snap1, "1回目のバックアップが空")

        with quiet():
            K.cmd_verify(Args(manifest=self.mpath()))
            K.cmd_restore(Args(manifest=self.mpath(), confirm="RESTORE_ORIGINALS"))

        rep2 = os.path.join(self.base, "report2")
        with quiet():
            K.cmd_diagnose(Args(root=self.root, report_dir=rep2))
            K.cmd_apply(Args(root=self.root, report_dir=rep2,
                             backup_dir=self.bak, confirm="REMOVE_EMBEDDED_IMAGES"))
        m2 = json.load(open(os.path.join(rep2, K.MANIFEST_NAME)))
        bdir2 = m2["backup_dir"]

        self.assertNotEqual(os.path.realpath(bdir1), os.path.realpath(bdir2),
                            "2回目が1回目と同じ場所へ書いた")
        self.assertEqual(snap1, sha_tree(bdir1), "1回目のバックアップが上書きされた")

    def test_P0_4b_apply_refuses_preexisting_backup_file(self):
        """バックアップ先に同名ファイルが先にあれば、上書きせず失敗させる。"""
        self.diagnose()
        real_mkdir = os.mkdir
        planted = {}

        def mkdir_then_plant(path, *a, **kw):
            r = real_mkdir(path, *a, **kw)
            if os.path.basename(path).startswith("run-") and not planted:
                p = os.path.join(path, "t02_one_image.jsonl")
                with open(p, "wb") as fh:
                    fh.write(b"OLD-BACKUP")
                planted["p"] = p
            return r

        K.os.mkdir = mkdir_then_plant
        try:
            with quiet():
                K.cmd_apply(Args(root=self.root, report_dir=self.rep,
                                 backup_dir=self.bak, confirm="REMOVE_EMBEDDED_IMAGES"))
        finally:
            K.os.mkdir = real_mkdir

        self.assertEqual(b"OLD-BACKUP", open(planted["p"], "rb").read(),
                         "既存のバックアップを上書きした（P0-4の再発）")
        m = json.load(open(self.mpath()))
        self.assertNotEqual(self.entry(m, "t02_one_image.jsonl")["status"], "changed")

    # ---- P0-5 未知の記録種別でも処理してしまう -----------------------------
    def test_P0_5_unknown_event_type_at_known_pointer_is_held(self):
        """場所が既知でも、記録の種類が未知なら触らない。"""
        p = os.path.join(self.root, "zz_future_event.jsonl")
        payload = "A" * 200000
        line = json.dumps({
            "type": "some_future_record_type",
            "payload": {"type": "message", "content": [
                {"type": "input_image",
                 "image_url": "data:image/png;base64," + payload}]}}, ensure_ascii=False)
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(line + "\n")
        os.utime(p, (time.time() - 90000, time.time() - 90000))

        info, _ = K.analyze_file(p)
        self.assertEqual(info["status"], "held",
                         "未知の記録種別を処理対象にした（P0-5の再発）")
        self.assertGreater(info["unknown_hits"], 0)

    def test_P0_5b_known_contract_still_processed(self):
        """契約を締めた副作用で、実在する5通りが処理されなくなっていないこと。"""
        for name in ("t02_one_image.jsonl", "t03_multi_image.jsonl",
                     "t04_attached.jsonl", "t04b_custom_tool_out.jsonl",
                     "t04c_mcp_screenshot.jsonl"):
            info, _ = K.analyze_file(os.path.join(self.root, name))
            self.assertEqual(info["status"], "candidate",
                             "%s が処理されなくなった（締めすぎ）: %s" % (name, info["reason"]))

    # ---- P0-6 commit が部分削除する ----------------------------------------
    def test_P0_6_commit_is_all_or_nothing(self):
        """1件でも記録と合わなければ、1件も消さない。"""
        self.full_cycle()
        with quiet():
            K.cmd_verify(Args(manifest=self.mpath()))
        m = json.load(open(self.mpath()))
        bdir = m["backup_dir"]
        changed = [e for e in m["files"] if e["status"] == "changed"]
        self.assertGreater(len(changed), 1, "この試験には2本以上の対象が要る")
        snap = sha_tree(bdir)

        # 最後の1件だけ改ざんする（先頭が先に消されていないかを見たいので後ろ）
        victim = os.path.join(bdir, changed[-1]["backup_path"])
        with open(victim, "ab") as fh:
            fh.write(b"x")

        with self.assertRaises(K.Halt):
            with quiet():
                K.cmd_commit(Args(manifest=self.mpath(),
                                  confirm="DELETE_IMAGE_BACKUP_IRREVERSIBLY"))
        after = sha_tree(bdir)
        self.assertEqual(sorted(snap.keys()), sorted(after.keys()),
                         "先頭のバックアップが先に消えた（P0-6の再発）")

    # ---- P0-7 self-test の作業場が危険 -------------------------------------
    def test_P0_7a_self_test_rejects_real_data_dirs(self):
        """実データの置き場は、たとえ「まだ無い下位フォルダ」でも作業場にしない。

        判定だけの関数を直接呼ぶ。ここで cmd_self_test を呼ぶと、
        もし判定が壊れていたとき試験自体が ~/.codex に作り物を書いてしまう。
        """
        bads = ["~/.codex", "~/.codex/sessions", "~/Documents", "~/Downloads", "~"]
        # 「まだ存在しない」場所は、空フォルダ判定では止められない＝禁止一覧だけが頼り
        bads.append("~/.codex/kesazu-selftest-never-create-me")
        for bad in bads:
            full = os.path.expanduser(bad)
            with self.assertRaises(K.Halt, msg="%s を作業場として受け入れた" % bad):
                K.check_selftest_workdir(full)
            self.assertFalse(os.path.exists(os.path.expanduser(
                "~/.codex/kesazu-selftest-never-create-me")), "実データ側に作ってしまった")

    def test_P0_7b_self_test_rejects_non_empty_dir(self):
        d = os.path.join(self.base, "notempty")
        os.makedirs(d)
        with open(os.path.join(d, "mine.txt"), "wb") as fh:
            fh.write(b"hi")
        with self.assertRaises(K.Halt):
            K.check_selftest_workdir(d)
        with self.assertRaises(K.Halt):
            with quiet():
                K.cmd_self_test(Args(workdir=d))
        self.assertEqual(b"hi", open(os.path.join(d, "mine.txt"), "rb").read())


class T_P1_Regression(Base):

    def test_P1_diagnose_does_not_destroy_restore_info(self):
        """apply 済みの記録を diagnose で上書きしない（復元先を見失わないため）。"""
        self.full_cycle()
        before = open(self.mpath(), "rb").read()
        with self.assertRaises(K.Halt):
            with quiet():
                K.cmd_diagnose(Args(root=self.root, report_dir=self.rep))
        self.assertEqual(before, open(self.mpath(), "rb").read(),
                         "apply 済みの記録を上書きした")

    def test_P1_self_test_works_while_codex_is_running(self):
        """Codex を開いたままでも self-test は通る（作り物しか見ないため）。

        買った人が最初に走らせるのがこれ。ここで落ちると
        「壊れている」と受け取られる。
        """
        K.codex_running = lambda: True          # 起動中のふりをする
        wd = os.path.join(self.base, "st_running")
        with quiet() as b:
            rc = K.cmd_self_test(Args(workdir=wd))
        self.assertEqual(rc, 0, "Codex 起動中に self-test が失敗した:\n" + b.getvalue()[-800:])

    def test_P1_diagnose_all_held_points_back_to_diagnose(self):
        """起動中で全部 HOLD のとき、対象0本の apply へ案内しない。"""
        K.codex_running = lambda: True
        _, out = self.diagnose()
        self.assertIn("もう一度 diagnose", out,
                      "全部 HOLD なのに apply を案内している")

    def test_P1_broken_marker_is_held(self):
        """札の形が崩れていたら、処理済みとみなさず HOLD する。"""
        p = os.path.join(self.root, "zz_broken_marker.jsonl")
        line = json.dumps({
            "type": "response_item",
            "payload": {"type": "message", "content": [
                {"type": "input_image",
                 "image_url": K.MARKER_PREFIX + "sha256=NOT-A-HASH;bytes=???"}]}},
            ensure_ascii=False)
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(line + "\n")
        os.utime(p, (time.time() - 90000, time.time() - 90000))
        info, _ = K.analyze_file(p)
        self.assertEqual(info["status"], "held", "崩れた札を処理済み扱いした")

    def test_P1_apply_returns_nonzero_when_a_file_fails(self):
        """1本でも失敗したら、終了コードで分かるようにする。"""
        self.diagnose()
        p = os.path.join(self.root, "t02_one_image.jsonl")
        with open(p, "ab") as fh:      # 診断後に中身を変える → その1本は失敗する
            fh.write(b'{"type":"response_item","payload":{"type":"message"}}\n')
        with quiet():
            rc = K.cmd_apply(Args(root=self.root, report_dir=self.rep,
                                  backup_dir=self.bak, confirm="REMOVE_EMBEDDED_IMAGES"))
        self.assertNotEqual(rc, 0, "失敗があったのに終了コードが 0")

    def test_P1_root_lock_blocks_second_report_dir(self):
        """report 先を変えても、同じ対象フォルダを二重に処理しない。"""
        self.diagnose()
        held = K.Lock(path=K.root_lock_path(K.resolve_root(self.root)), label="test")
        held.__enter__()
        try:
            with self.assertRaises(K.Halt):
                with quiet():
                    K.cmd_apply(Args(root=self.root, report_dir=self.rep,
                                     backup_dir=self.bak,
                                     confirm="REMOVE_EMBEDDED_IMAGES"))
        finally:
            held.__exit__()


class T_P1_EmptyVerify(Base):
    """
    P1（2026-08-05 巡回で発見）
    「何も照合していない」ときに verify が「すべて一致しました」と出す問題。

    verify は利用者に安心を渡す担当なので、ここが緑を出し間違えると
    「照合が通ったから消してよい」と読まれる。失敗台帳#30（0件は「無い」と
    「取れていない」の区別がつかない）と同じ型。
    """

    def _plain_only_root(self):
        """画像がまったく無いログだけの対象フォルダを作る。"""
        root = os.path.join(self.base, "plain")
        os.makedirs(root)
        p = os.path.join(root, "only_talk.jsonl")
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(json.dumps({"type": "response_item", "payload": {
                "type": "message", "content": [
                    {"type": "input_text", "text": "画像のない会話"}]}},
                ensure_ascii=False) + "\n")
        old = time.time() - 3 * 86400
        os.utime(p, (old, old))
        return root

    def test_P1_verify_says_nothing_to_check_when_no_candidates(self):
        """取り除くものが0本だったとき、verify は『一致した』と言わない。"""
        root = self._plain_only_root()
        rep = os.path.join(self.base, "rep_plain")
        with quiet():
            K.cmd_diagnose(Args(root=root, report_dir=rep))
            K.cmd_apply(Args(root=root, report_dir=rep,
                             backup_dir=os.path.join(self.base, "bak_plain"),
                             confirm="REMOVE_EMBEDDED_IMAGES"))
        mp = os.path.join(rep, K.MANIFEST_NAME)
        with quiet() as b:
            rc = K.cmd_verify(Args(manifest=mp))
        out = b.getvalue()
        self.assertNotEqual(rc, 0, "0本しか見ていないのに verify が成功を返した")
        self.assertNotIn("すべて一致しました", out, "何も照合していないのに『すべて一致』と出した")
        self.assertIn("検証対象がありません", out)
        self.assertIsNone(json.load(open(mp)).get("verified_at"),
                          "照合していないのに verify 済みの印を付けた")

    def test_P1_apply_records_that_it_did_nothing(self):
        """対象0本でも、apply は『apply として動いた』ことを記録に残す。"""
        root = self._plain_only_root()
        rep = os.path.join(self.base, "rep_plain2")
        with quiet():
            K.cmd_diagnose(Args(root=root, report_dir=rep))
            K.cmd_apply(Args(root=root, report_dir=rep,
                             backup_dir=os.path.join(self.base, "bak_plain2"),
                             confirm="REMOVE_EMBEDDED_IMAGES"))
        m = json.load(open(os.path.join(rep, K.MANIFEST_NAME)))
        self.assertEqual(m["mode"], "apply", "記録が diagnose のまま残っている")
        self.assertEqual(m["candidates"], 0)
        self.assertIsNone(m["backup_dir"])

    def _break_every_target(self):
        """診断後に全部の .jsonl を書き換えて、apply を全滅させる（サブフォルダも含む）。"""
        n = 0
        for dp, _dn, fn in os.walk(self.root):
            for name in fn:
                if not name.endswith(".jsonl"):
                    continue
                with open(os.path.join(dp, name), "ab") as fh:
                    fh.write(b'{"type":"response_item","payload":{"type":"message"}}\n')
                n += 1
        return n

    def test_P1_verify_flags_run_where_every_file_failed(self):
        """apply が全滅した記録を、verify が緑にしない（いちばん危ない筋）。"""
        self.diagnose()
        self._break_every_target()
        with quiet():
            rc_apply = K.cmd_apply(Args(root=self.root, report_dir=self.rep,
                                        backup_dir=self.bak,
                                        confirm="REMOVE_EMBEDDED_IMAGES"))
        m = json.load(open(self.mpath()))
        self.assertEqual([e for e in m["files"] if e["status"] == "changed"], [],
                         "この試験は『1本も成功しない』状態を作る前提")
        self.assertNotEqual(rc_apply, 0)

        with quiet() as b:
            rc = K.cmd_verify(Args(manifest=self.mpath()))
        self.assertNotEqual(rc, 0, "全部失敗した記録を verify が通した")
        self.assertNotIn("すべて一致しました", b.getvalue())
        self.assertIsNone(json.load(open(self.mpath())).get("verified_at"))

    def test_P1_commit_blocked_after_failed_run(self):
        """全滅した記録では commit まで進めない（verify 済みにならないため）。"""
        self.diagnose()
        self._break_every_target()
        with quiet():
            K.cmd_apply(Args(root=self.root, report_dir=self.rep,
                             backup_dir=self.bak, confirm="REMOVE_EMBEDDED_IMAGES"))
            K.cmd_verify(Args(manifest=self.mpath()))
        with self.assertRaises(K.Halt):
            K.cmd_commit(Args(manifest=self.mpath(),
                              confirm="DELETE_IMAGE_BACKUP_IRREVERSIBLY"))

    def test_P1_verify_reports_failed_files_instead_of_hiding_them(self):
        """成功と失敗が混ざったとき、失敗を黙って飛ばさない（成功分は commit できる）。"""
        self.diagnose()
        p = os.path.join(self.root, "t02_one_image.jsonl")
        with open(p, "ab") as fh:                 # この1本だけ失敗させる
            fh.write(b'{"type":"response_item","payload":{"type":"message"}}\n')
        with quiet():
            K.cmd_apply(Args(root=self.root, report_dir=self.rep,
                             backup_dir=self.bak, confirm="REMOVE_EMBEDDED_IMAGES"))
        m = json.load(open(self.mpath()))
        self.assertTrue([e for e in m["files"] if e["status"] == "changed"])
        self.assertTrue([e for e in m["files"] if e["status"] == "failed"])

        with quiet() as b:
            rc = K.cmd_verify(Args(manifest=self.mpath()))
        out = b.getvalue()
        self.assertEqual(rc, 0, "成功した分まで巻き添えで失敗にした")
        self.assertIn("t02_one_image.jsonl", out, "失敗した1本を画面に出していない")
        self.assertIn("処理できなかったものが 1 本", out)
        self.assertIsNotNone(json.load(open(self.mpath())).get("verified_at"))

    def test_P1_restore_message_is_understandable_without_apply(self):
        """apply していない記録に restore を打っても、意味の通る言葉で止まる。"""
        root = self._plain_only_root()
        rep = os.path.join(self.base, "rep_plain3")
        with quiet():
            K.cmd_diagnose(Args(root=root, report_dir=rep))
        mp = os.path.join(rep, K.MANIFEST_NAME)
        with self.assertRaises(K.Halt) as cm:
            K.cmd_restore(Args(manifest=mp, confirm="RESTORE_ORIGINALS"))
        msg = str(cm.exception)
        self.assertNotIn("None", msg, "利用者に None をそのまま見せている")
        self.assertIn("apply", msg)

    def test_P1_verify_after_commit_does_not_cry_about_missing_backup(self):
        """commit で消した控えを、あとの verify が『無くなっている』と騒がない。"""
        self.full_cycle()
        with quiet():
            K.cmd_verify(Args(manifest=self.mpath()))
            K.cmd_commit(Args(manifest=self.mpath(),
                              confirm="DELETE_IMAGE_BACKUP_IRREVERSIBLY"))
        with quiet() as b:
            rc = K.cmd_verify(Args(manifest=self.mpath()))
        self.assertEqual(rc, 0,
                         "commit で意図的に消した控えを『異常』と判定した:\n" + b.getvalue()[-500:])
        self.assertNotIn("バックアップがありません", b.getvalue())


class T_V2_CommitInterruptAndCause(Base):
    """
    v2候補 B・C の回帰（2026-08-05 巡回で発見・v1.2.0 で修正）

    B: commit の削除中に中断すると、控えは減っているのに記録が消す前のまま残り、
       あとの verify が「自分で消した控え」を異常として出していた。
    C: commit のあとに restore を打つと「バックアップがありません: <パス>」だけが出て、
       自分が消したのか事故で消えたのかを利用者が判別できなかった。

    どちらもログ本体は失われない。壊れるのは「利用者が事実を読み取れるか」。
    """

    def setUp(self):
        Base.setUp(self)
        self.full_cycle()
        with quiet():
            self.assertEqual(0, K.cmd_verify(Args(manifest=self.mpath())),
                             "この試験は verify が通った状態から始める前提")
        m = json.load(open(self.mpath()))
        self.changed = [e for e in m["files"]
                        if e["status"] == "changed" and e.get("backup_path")]
        # 控えは backup_dir（run-… の下）に置かれる。self.bak はその親。
        # ここを取り違えると「無いこと」を確かめる試験が全部素通りする。
        self.bdir = m["backup_dir"]
        for e in self.changed:
            self.assertTrue(os.path.exists(os.path.join(self.bdir, e["backup_path"])),
                            "控えの置き場を取り違えている（試験が素通りする）")

    def _commit(self, break_at=None):
        """break_at 本目を消す直前で中断させる。None なら最後まで通す。"""
        real = K.os.unlink
        seen = {"n": 0}

        def boom(p):
            seen["n"] += 1
            if break_at is not None and seen["n"] == break_at:
                raise KeyboardInterrupt("中断（Ctrl-C / 電源断の相当）")
            return real(p)

        K.os.unlink = boom
        try:
            with quiet() as b:
                K.cmd_commit(Args(manifest=self.mpath(),
                                  confirm="DELETE_IMAGE_BACKUP_IRREVERSIBLY"))
            return b.getvalue()
        finally:
            K.os.unlink = real

    def _backups_left(self):
        n = 0
        for dp, _dn, fn in os.walk(self.bak):
            n += len(fn)
        return n

    def test_v2B_manifest_keeps_up_when_commit_is_interrupted(self):
        """1本消すごとに記録へ書く。中断しても、記録と実態がずれない。"""
        if len(self.changed) < 2:
            self.skipTest("控えが1本しかないので途中中断を作れない")
        before = self._backups_left()
        with self.assertRaises(KeyboardInterrupt):
            self._commit(break_at=2)          # 1本消した直後に落ちる
        m = json.load(open(self.mpath()))
        marked = sum(1 for e in m["files"] if e.get("backup_committed"))
        self.assertEqual(before - self._backups_left(), marked,
                         "実際に消した本数と、記録に載っている本数が違う")
        self.assertEqual(m.get("mode"), "committing",
                         "commit の途中で止まったことが記録に残っていない")

    def test_v2B_verify_after_interrupted_commit_is_not_called_damage(self):
        """中断で消えた控えを、verify が事故として赤で出さない。"""
        if len(self.changed) < 2:
            self.skipTest("控えが1本しかないので途中中断を作れない")
        with self.assertRaises(KeyboardInterrupt):
            self._commit(break_at=2)
        with quiet() as b:
            rc = K.cmd_verify(Args(manifest=self.mpath()))
        out = b.getvalue()
        self.assertEqual(rc, 0,
                         "自分で消した控えを異常として落としている:\n" + out[-500:])
        self.assertNotIn("✗ バックアップがありません", out)
        self.assertIn("commit が途中で止まっています", out,
                      "片づけが途中であることを本人に伝えていない")

    def test_v2B_rerun_commit_finishes_what_was_interrupted(self):
        """もう一度 commit を打てば、中断した片づけを最後まで終えられる。"""
        if len(self.changed) < 2:
            self.skipTest("控えが1本しかないので途中中断を作れない")
        with self.assertRaises(KeyboardInterrupt):
            self._commit(break_at=2)
        self._commit()                        # 2回目。ここで止まったら回収不能になる
        m = json.load(open(self.mpath()))
        self.assertEqual(m.get("mode"), "commit")
        self.assertTrue(m.get("committed_at"))
        self.assertEqual(0, self._backups_left(), "2回目の commit で消し残しがある")
        for e in self.changed:
            self.assertTrue(e2 := self.entry(m, os.path.basename(e["relative_path"])))
            self.assertTrue(e2.get("backup_committed"),
                            "消したのに記録へ載っていない: %s" % e["backup_path"])

    def test_v2B_verify_survives_the_gap_between_delete_and_record(self):
        """
        いちばん狭い窓: 控えを消した直後・記録に書く前に落ちた場合。

        1本ごとに記録しても、この一瞬だけは記録が実態に追いつけない。
        そこを『事故』として赤で出すと、利用者は自分が消したものに驚く。
        （この試験が無いと、verify の committing 分岐は誰も通らない死に枝になる）
        """
        if len(self.changed) < 2:
            self.skipTest("控えが1本しかないので途中中断を作れない")
        real_write = K.write_json
        seen = {"n": 0}

        def stop_before_recording(path, obj):
            seen["n"] += 1
            if seen["n"] == 2:      # 1回目=committing の宣言、2回目=1本目を消した記録
                raise KeyboardInterrupt("記録を書く直前で電源が落ちた相当")
            return real_write(path, obj)

        K.write_json = stop_before_recording
        try:
            with self.assertRaises(KeyboardInterrupt):
                with quiet():
                    K.cmd_commit(Args(manifest=self.mpath(),
                                      confirm="DELETE_IMAGE_BACKUP_IRREVERSIBLY"))
        finally:
            K.write_json = real_write

        m = json.load(open(self.mpath()))
        self.assertEqual(m.get("mode"), "committing")
        self.assertEqual(0, sum(1 for e in m["files"] if e.get("backup_committed")),
                         "この試験は『消えたが記録に載っていない』状態を作る前提")
        with quiet() as b:
            rc = K.cmd_verify(Args(manifest=self.mpath()))
        out = b.getvalue()
        self.assertEqual(rc, 0, "記録に載る前に落ちた1本を事故扱いした:\n" + out[-500:])
        self.assertIn("commit の途中で止まっています", out)
        self.assertNotIn("✗ バックアップがありません", out)

    def test_v2C_restore_after_commit_names_the_cause(self):
        """commit 後の restore は『あなたが消した』と言う。事故に見せない。"""
        self._commit()
        with self.assertRaises(K.Halt) as cm:
            with quiet():
                K.cmd_restore(Args(manifest=self.mpath(), confirm="RESTORE_ORIGINALS"))
        msg = str(cm.exception)
        self.assertIn("commit", msg)
        self.assertIn("事故ではありません", msg)
        self.assertNotIn("バックアップがありません:", msg,
                         "事故のときと同じ文言を出している")

    def test_v2C_missing_backup_without_commit_is_still_unexpected(self):
        """commit していないのに控えが無いのは、いまも『想定外』として止める。"""
        os.unlink(os.path.join(self.bdir, self.changed[0]["backup_path"]))
        with self.assertRaises(K.Halt) as cm:
            with quiet():
                K.cmd_restore(Args(manifest=self.mpath(), confirm="RESTORE_ORIGINALS"))
        self.assertIn("想定外", str(cm.exception),
                      "本当の事故を、commit で消した場合と同じ顔で流している")


# ===========================================================================
#  v1.3.0 / 敵対入力（壊れた入力・意地の悪い入力）の常設回帰
#
#  2026-08-05、巡回道具（tools/patrol_kesazu.py fuzz）で 32 項目を1回だけ確かめた。
#  1回だけの検査は、次に誰かが実装を触ったときに何も守らない。
#  Sol Ultra の再受入（v1.2.1）が終わって的が止まったので、常設の回帰へ移す。
#
#  見るのは2つだけ:
#    ① 落ちない（壊れた入力で例外を投げて止まらない）
#    ② 触ってはいけないものが1バイトも変わらない／戻したら完全一致
#
#  1周（diagnose→apply→verify→restore）は 3MB 行を含んで重いので、
#  setUpClass で1回だけ走らせ、各試験はその実測値に対して確かめる。
# ===========================================================================

IMG_HEAD = "data:image/png;base64,"

# 意地悪な名前（空白・日本語・絵文字・引用符・%s）。書式指定子として解釈されると壊れる。
WEIRD_NAME = "f09 空白 日本語 🙂 'q' %s.jsonl"


def _img(nchars=4096, seed="A"):
    return IMG_HEAD + (seed * nchars)


def _rec_message(img):
    """契約内の記録（response_item / message / content[] / image_url）を1行ぶん。"""
    return json.dumps({
        "type": "response_item",
        "payload": {"type": "message", "role": "user",
                    "content": [{"type": "input_image", "image_url": img}]},
    }, ensure_ascii=False)


class T_V3_HostileInput(unittest.TestCase):
    """壊れた入力32項目。Base は使わない（標準 fixtures ではなく自前の意地悪な木を作る）。"""

    HUGE_CHARS = 3 * 1024 * 1024        # 1行およそ3MB

    # 触ってはいけない＝処理対象にしてはいけない6本
    UNTOUCHABLE = ("f02_brokenjson.jsonl", "f03_badutf8.jsonl", "f04_empty.jsonl",
                   "f08_nul.jsonl", "f15_collision.jsonl", "f16_textonly.jsonl")
    # 普通に処理できるはずの6本
    PROCESSABLE = ("f01_ok.jsonl", "f05_nonewline.jsonl", "f06_crlf.jsonl",
                   WEIRD_NAME, "f10_huge.jsonl", "f11_readonly.jsonl")

    @classmethod
    def setUpClass(cls):
        import traceback

        cls.base = tempfile.mkdtemp(prefix="kesazu-hostile-")
        cls.root = os.path.join(cls.base, "sessions")
        cls.rep = os.path.join(cls.base, "report")
        cls.bak = os.path.join(cls.base, "backup")
        os.makedirs(cls.root)
        cls._real_codex_running = K.codex_running
        K.codex_running = lambda: False

        def put(name, data):
            p = os.path.join(cls.root, name)
            with open(p, "wb") as f:
                f.write(data)
            old = time.time() - 48 * 3600    # 24時間ルールで HOLD にならないよう古くする
            os.utime(p, (old, old))
            return p

        line_ok = (_rec_message(_img(4096, "A")) + "\n").encode("utf-8")

        put("f01_ok.jsonl", line_ok)
        put("f02_brokenjson.jsonl", line_ok + b"{ this is not json\n")
        put("f03_badutf8.jsonl",
            line_ok + b'{"type":"response_item","payload":{"x":"\xff\xfe"}}\n')
        put("f04_empty.jsonl", b"")
        put("f05_nonewline.jsonl", _rec_message(_img(4096, "B")).encode("utf-8"))
        put("f06_crlf.jsonl", _rec_message(_img(4096, "C")).encode("utf-8") + b"\r\n")
        put("f07_bom.jsonl", b"\xef\xbb\xbf" + line_ok)
        put("f08_nul.jsonl",
            b'{"type":"response_item","payload":{"type":"message","content":'
            b'[{"type":"input_image","image_url":"' + IMG_HEAD.encode() +
            b"D" * 2000 + b'\x00"}]}}\n')
        put(WEIRD_NAME, _rec_message(_img(4096, "E")).encode("utf-8") + b"\n")
        put("f10_huge.jsonl",
            (_rec_message(_img(cls.HUGE_CHARS, "F")) + "\n").encode("utf-8"))
        p_ro = put("f11_readonly.jsonl",
                   (_rec_message(_img(4096, "G")) + "\n").encode("utf-8"))
        os.chmod(p_ro, 0o444)

        # 同じ画像文字列が「画像の場所」と「本文の場所」の両方に出る行。
        # 実データ59件の罠と同じ形。バイト置換は行全体に効くので、
        # 守りが無いと本文まで書き換わる。
        collide = _img(4096, "H")
        put("f15_collision.jsonl", (json.dumps({
            "type": "response_item",
            "payload": {"type": "message", "role": "user", "content": [
                {"type": "input_image", "image_url": collide},
                {"type": "text", "text": "この画像です: " + collide},
            ]},
        }, ensure_ascii=False) + "\n").encode("utf-8"))
        # 本文にだけ画像文字列がある（画像ではないので触ってはいけない）
        put("f16_textonly.jsonl", (json.dumps({
            "type": "response_item",
            "payload": {"type": "message", "role": "user", "content": [
                {"type": "text", "text": "貼ります: " + _img(4096, "I")},
            ]},
        }, ensure_ascii=False) + "\n").encode("utf-8"))

        # .jsonl という名前を持つ、通常ファイルでないもの
        os.makedirs(os.path.join(cls.root, "f12_dir.jsonl"))
        try:
            os.mkfifo(os.path.join(cls.root, "f13_fifo.jsonl"))
            cls.fifo = True
        except Exception:
            cls.fifo = False
        os.symlink(os.path.join(cls.root, "f01_ok.jsonl"),
                   os.path.join(cls.root, "f14_link.jsonl"))

        # 処理前の現物（通常ファイルだけ）
        cls.before = {}
        for dp, dn, fn in os.walk(cls.root):
            for n in fn:
                p = os.path.join(dp, n)
                if os.path.islink(p) or not stat.S_ISREG(os.lstat(p).st_mode):
                    continue
                cls.before[p] = (open(p, "rb").read(),
                                 stat.S_IMODE(os.lstat(p).st_mode))

        # 1周まわす
        buf = io.StringIO()
        cls.crash = None
        cls.crash_restore = None
        cls.rc_verify = None
        mpath = os.path.join(cls.rep, K.MANIFEST_NAME)
        try:
            with contextlib.redirect_stdout(buf):
                K.cmd_diagnose(Args(root=cls.root, report_dir=cls.rep))
                K.cmd_apply(Args(root=cls.root, report_dir=cls.rep,
                                 backup_dir=cls.bak,
                                 confirm="REMOVE_EMBEDDED_IMAGES"))
                cls.rc_verify = K.cmd_verify(Args(manifest=mpath))
        except BaseException:
            cls.crash = traceback.format_exc()
        cls.screen = buf.getvalue()

        cls.st = {}
        if os.path.exists(mpath):
            m = json.load(open(mpath))
            for e in m["files"]:
                cls.st[os.path.basename(e["relative_path"])] = (
                    e["status"], e.get("reason", ""))

        # 処理後の現物
        cls.after = {}
        for p in cls.before:
            cls.after[p] = (open(p, "rb").read(),
                            stat.S_IMODE(os.lstat(p).st_mode))

        # 戻す
        cls.restore_diff = []
        if os.path.exists(mpath):
            try:
                with contextlib.redirect_stdout(io.StringIO()):
                    K.cmd_restore(Args(manifest=mpath, confirm="RESTORE_ORIGINALS"))
            except BaseException:
                cls.crash_restore = traceback.format_exc()
            cls.restore_diff = sorted(
                os.path.basename(p) for p, (b, mode) in cls.before.items()
                if open(p, "rb").read() != b)

    @classmethod
    def tearDownClass(cls):
        K.codex_running = cls._real_codex_running
        shutil.rmtree(cls.base, ignore_errors=True)

    @classmethod
    def p(cls, fn):
        return os.path.join(cls.root, fn)

    @classmethod
    def status_of(cls, fn):
        return cls.st.get(fn, ("(記録に無い)", ""))[0]

    # --- ① 落ちないこと ------------------------------------------------
    def test_v3F01_no_crash_on_hostile_input(self):
        """壊れた入力を並べても、例外で止まらない。"""
        self.assertIsNone(self.crash, "1周の途中で例外が出た:\n%s" % (self.crash or ""))

    def test_v3F02_no_crash_on_restore(self):
        self.assertIsNone(self.crash_restore,
                          "restore で例外が出た:\n%s" % (self.crash_restore or ""))

    def test_v3F03_verify_passes(self):
        self.assertEqual(0, self.rc_verify,
                         "壊れた入力のあと verify が通らない（rc=%r）" % (self.rc_verify,))

    # --- ② 触ってはいけないものが変わっていないこと --------------------
    def test_v3F04_untouchable_files_are_byte_identical(self):
        """触ってはいけない6本が1バイトも変わっていない。"""
        for fn in self.UNTOUCHABLE:
            with self.subTest(fn=fn, status=self.status_of(fn)):
                p = self.p(fn)
                self.assertEqual(self.before[p][0], self.after[p][0],
                                 "%s を書き換えた（判定=%s）" % (fn, self.status_of(fn)))

    def test_v3F05_broken_json_is_held(self):
        self.assertEqual("held", self.status_of("f02_brokenjson.jsonl"))

    def test_v3F06_bad_utf8_is_held(self):
        self.assertEqual("held", self.status_of("f03_badutf8.jsonl"))

    def test_v3F07_nul_byte_is_held(self):
        self.assertEqual("held", self.status_of("f08_nul.jsonl"))

    def test_v3F08_empty_file_is_skipped(self):
        self.assertEqual("skipped", self.status_of("f04_empty.jsonl"))

    # --- BOM: held にはならないのが正しい（json.loads が utf-8-sig で読める）。
    #     見るべきは「BOM を落としていないか」「壊していないか」「画像は取れたか」。
    def test_v3F09_bom_is_preserved(self):
        b = self.after[self.p("f07_bom.jsonl")][0]
        self.assertTrue(b.startswith(b"\xef\xbb\xbf"), "BOM を落とした（先頭=%r）" % b[:6])

    def test_v3F10_bom_file_is_still_valid_json(self):
        b = self.after[self.p("f07_bom.jsonl")][0]
        json.loads(b.splitlines()[0])        # 例外が出たら失敗

    def test_v3F11_bom_file_image_removed(self):
        b = self.after[self.p("f07_bom.jsonl")][0]
        self.assertNotIn(IMG_HEAD.encode(), b, "BOM 付きの画像が残った")

    # --- 本文と衝突する行 ----------------------------------------------
    def test_v3F12_colliding_line_is_not_rewritten(self):
        """同じ画像文字列が本文にも出る行は、数が合わないので書き換えない。"""
        self.assertIn(self.status_of("f15_collision.jsonl"),
                      ("held", "skipped", "failed", "(記録に無い)"),
                      "本文と衝突する行を書き換えた")

    def test_v3F13_text_only_image_string_is_skipped(self):
        self.assertEqual("skipped", self.status_of("f16_textonly.jsonl"))

    def test_v3F14_unprocessable_file_is_shown_on_screen(self):
        """書き換えられなかった1本を、記録に埋めて黙っていない。"""
        told = ("f15_collision" in self.screen or "失敗" in self.screen
                or "できません" in self.screen)
        self.assertTrue(told, "処理できなかった1本を画面で知らせていない:\n"
                              + self.screen[-600:])

    # --- 処理できるものは処理されること --------------------------------
    def test_v3F15_processable_files_are_changed(self):
        for fn in self.PROCESSABLE:
            with self.subTest(fn=fn):
                self.assertEqual("changed", self.status_of(fn),
                                 "%s が処理されていない" % fn)

    # --- 改行の作法 ------------------------------------------------------
    def test_v3F16_missing_final_newline_is_not_added(self):
        b = self.after[self.p("f05_nonewline.jsonl")][0]
        self.assertFalse(b.endswith(b"\n"), "最後の改行を勝手に足した（末尾=%r）" % b[-8:])

    def test_v3F17_crlf_is_preserved(self):
        b = self.after[self.p("f06_crlf.jsonl")][0]
        self.assertTrue(b.endswith(b"\r\n"), "CRLF を壊した（末尾=%r）" % b[-8:])

    # --- 権限 ------------------------------------------------------------
    def test_v3F18_permissions_are_preserved(self):
        for fn in ("f01_ok.jsonl", "f11_readonly.jsonl"):
            with self.subTest(fn=fn):
                p = self.p(fn)
                self.assertEqual(self.before[p][1], self.after[p][1],
                                 "%s の権限が変わった（前=%o 後=%o）"
                                 % (fn, self.before[p][1], self.after[p][1]))

    # --- 通常ファイルでない .jsonl を拾わないこと ------------------------
    def test_v3F19_directory_named_jsonl_is_excluded(self):
        self.assertNotIn("f12_dir.jsonl", self.st,
                         "フォルダを対象にした（判定=%s）" % self.status_of("f12_dir.jsonl"))

    def test_v3F20_fifo_named_jsonl_is_excluded(self):
        if not self.fifo:
            self.skipTest("この環境では名前付きパイプを作れない")
        self.assertNotIn("f13_fifo.jsonl", self.st, "名前付きパイプを対象にした")

    def test_v3F21_symlink_named_jsonl_is_excluded(self):
        self.assertNotIn("f14_link.jsonl", self.st, "symlink を対象にした")

    # --- 戻したら完全一致 ------------------------------------------------
    def test_v3F22_restore_is_byte_identical_for_every_file(self):
        self.assertEqual([], self.restore_diff,
                         "戻したのに一致しない: %s" % ", ".join(self.restore_diff))


if __name__ == "__main__":
    unittest.main(verbosity=2)
