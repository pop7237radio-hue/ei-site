# -*- coding: utf-8 -*-
"""
同梱の作り物（fixture）。

実際のユーザーの文章も、実際の画像も、一切入っていない。
形だけを 2026-08-05 の実測（既知4形式・罠3種）に合わせてある。
"""

import base64
import json
import os
import time

OLD = time.time() - 3 * 24 * 3600  # 24時間より前にしておく


def _img(seed, kb=2):
    raw = (str(seed) * 4096).encode()[: kb * 1024]
    return "data:image/png;base64," + base64.b64encode(raw).decode()


def _w(path, lines, mtime=OLD):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        for x in lines:
            fh.write(x if isinstance(x, str) else json.dumps(x, ensure_ascii=False))
            fh.write("\n")
    os.utime(path, (mtime, mtime))


def build_fixtures(root):
    os.makedirs(root, exist_ok=True)

    # T01 会話だけ
    _w(os.path.join(root, "t01_normal.jsonl"), [
        {"type": "response_item", "payload": {"type": "message", "role": "user",
                                              "content": [{"type": "input_text", "text": "こんにちは"}]}},
        {"type": "response_item", "payload": {"type": "message", "role": "assistant",
                                              "last_agent_message": "はい、承知しました。"}},
    ])

    # T02 既知フィールドに1枚
    _w(os.path.join(root, "t02_one_image.jsonl"), [
        {"type": "response_item", "payload": {"type": "message", "role": "user", "content": [
            {"type": "input_text", "text": "この画面を見て"},
            {"type": "input_image", "image_url": _img("a", 4)},
        ]}},
    ])

    # T03 1行に複数枚（同一行・別内容と同一内容の両方）
    same = _img("b", 3)
    _w(os.path.join(root, "t03_multi_image.jsonl"), [
        {"type": "compacted", "payload": {"replacement_history": [
            {"role": "user", "content": [
                {"type": "input_image", "image_url": _img("c", 2)},
                {"type": "input_image", "image_url": same},
                {"type": "input_image", "image_url": same},
            ]},
        ]}},
    ])

    # T04 添付・生成画像も同じ既知形式（output 経由）
    _w(os.path.join(root, "t04_attached.jsonl"), [
        {"type": "response_item", "payload": {"type": "function_call_output", "output": [
            {"type": "input_text", "text": "生成しました"},
            {"type": "input_image", "image_url": _img("d", 5)},
        ]}},
    ])

    # T04b custom_tool_call_output 経由（実測 2,433件・v1.0.1 では作り物が無かった）
    _w(os.path.join(root, "t04b_custom_tool_out.jsonl"), [
        {"type": "response_item", "payload": {"type": "custom_tool_call_output",
                                              "call_id": "c1", "output": [
            {"type": "input_text", "text": "撮りました"},
            {"type": "input_image", "image_url": _img("k", 4)},
        ]}},
    ])

    # T04c MCP のスクリーンショット（実測 1,629件・v1.0.1 では作り物が無かった）
    _w(os.path.join(root, "t04c_mcp_screenshot.jsonl"), [
        {"type": "event_msg", "payload": {"type": "mcp_tool_call_end", "call_id": "m1",
         "result": {"Ok": {"_meta": {"codex": {"toolSurface": {"screenshot": {
             "url": _img("l", 4)}}}}}}}},
    ])

    # T05 本文・保存されたコードの中に data URI の文字列（実測の罠3種）
    code = ('<html><body>\n  <img class="base" src="data:image/png;base64,'
            + base64.b64encode(b"X" * 900).decode() + '" />\n</body></html>')
    _w(os.path.join(root, "t05_text_datauri.jsonl"), [
        {"type": "event_msg", "payload": {"type": "agent_message",
                                          "message": "こう書きます: data:image/png;base64,"
                                                     + base64.b64encode(b"Y" * 800).decode()}},
        {"type": "event_msg", "payload": {"type": "agent_message",
                                          "last_agent_message": "src=\"data:image/png;base64,"
                                                                + base64.b64encode(b"Z" * 700).decode() + "\""}},
        {"type": "response_item", "payload": {"type": "patch_apply",
                                              "changes": {"/tmp/render.cjs": {"content": code}}}},
    ])

    # T06 壊れた JSON が1行
    _w(os.path.join(root, "t06_broken.jsonl"), [
        json.dumps({"type": "response_item", "payload": {"type": "message",
                    "content": [{"type": "input_image", "image_url": _img("e", 2)}]}}, ensure_ascii=False),
        '{"type": "response_item", "payload": {broken',
    ])

    # T07 未知の場所に画像
    _w(os.path.join(root, "t07_unknown.jsonl"), [
        {"type": "response_item", "payload": {"type": "some_new_event",
                                              "attachment": {"blob": _img("f", 2)}}},
    ])

    # T08 対象外の拡張子
    for name in ("t08_notes.txt", "t08_cache.db", "t08_noext"):
        p = os.path.join(root, name)
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(_img("g", 2))
        os.utime(p, (OLD, OLD))

    # T10 直近に更新されたもの
    _w(os.path.join(root, "t10_recent.jsonl"), [
        {"type": "response_item", "payload": {"type": "message", "content": [
            {"type": "input_image", "image_url": _img("h", 2)}]}},
    ], mtime=time.time())

    # T21 日本語・絵文字・長大行・エスケープ
    _w(os.path.join(root, "t21_jp.jsonl"), [
        {"type": "response_item", "payload": {"type": "message", "content": [
            {"type": "input_text", "text": "改行\\nタブ\\t引用\" バックスラッシュ\\\\ 🍚🐟 " + "あ" * 5000},
            {"type": "input_image", "image_url": _img("i", 6)},
            {"type": "input_text", "text": "末尾も日本語です。😀"},
        ]}},
    ])

    # サブフォルダにも1本（再帰の確認）
    _w(os.path.join(root, "sub", "t02b_one_image.jsonl"), [
        {"type": "response_item", "payload": {"type": "message", "content": [
            {"type": "input_image", "image_url": _img("j", 3)}]}},
    ])

    return root


def build_symlink_fixture(root, outside_target):
    """T09: root の外を指す symlink。"""
    link = os.path.join(root, "t09_link.jsonl")
    if os.path.lexists(link):
        os.unlink(link)
    os.symlink(outside_target, link)
    return link
